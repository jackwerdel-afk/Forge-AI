<?php
/**
 * Plugin Name: Forge AI — Website Intelligence
 * Plugin URI: https://forge-ai-six-psi.vercel.app
 * Description: Real-time building alerts, AI auto-fix, and continuous monitoring. A product of Werdel Global Systems.
 * Version: 2.0.0
 * Author: Werdel Global Systems
 */

if (!defined('ABSPATH')) exit;

register_activation_hook(__FILE__, function() {
    add_option('forge_ai_token', '');
    add_option('forge_ai_anthropic_key', '');
    add_option('forge_ai_alerts', '1');
    add_option('forge_ai_auto_fix', '1');
    add_option('forge_ai_app_password', '');
});

// ── AJAX: ENABLE AUTO-FIX ────────────────────────────────
add_action('wp_ajax_forge_ai_enable_autofix', function() {
    check_ajax_referer('forge_ai_nonce', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Permission denied.']);
        return;
    }

    $token = get_option('forge_ai_token', '');
    if (empty($token)) {
        wp_send_json_error(['message' => 'Please save your Forge AI token first.']);
        return;
    }

    // Generate WordPress Application Password for Forge AI
    $current_user = wp_get_current_user();
    
    // Check if we already have one stored
    $existing = get_option('forge_ai_app_password', '');
    if (!empty($existing)) {
        // Already enabled - just update Forge AI with credentials
        $response = forge_ai_send_credentials($token, $existing, $current_user->user_login);
        if ($response) {
            wp_send_json_success(['message' => 'Auto-fix already enabled.']);
        } else {
            wp_send_json_error(['message' => 'Could not connect to Forge AI. Please try again.']);
        }
        return;
    }

    // Generate new Application Password
    if (!function_exists('WP_Application_Passwords')) {
        require_once ABSPATH . 'wp-includes/class-wp-application-passwords.php';
    }

    $app_password_result = WP_Application_Passwords::create_new_application_password(
        $current_user->ID,
        ['name' => 'Forge AI Auto-fix', 'app_id' => 'forge-ai-autofix']
    );

    if (is_wp_error($app_password_result)) {
        wp_send_json_error(['message' => 'Could not create application password: ' . $app_password_result->get_error_message()]);
        return;
    }

    // app_password_result[0] is the plain text password (only shown once)
    $plain_password = $app_password_result[0];
    $credentials = base64_encode($current_user->user_login . ':' . $plain_password);
    
    // Store credentials
    update_option('forge_ai_app_password', $credentials);
    update_option('forge_ai_auto_fix', '1');

    // Send credentials to Forge AI
    $response = forge_ai_send_credentials($token, $credentials, $current_user->user_login);
    
    if ($response) {
        wp_send_json_success(['message' => 'Auto-fix enabled successfully.']);
    } else {
        wp_send_json_error(['message' => 'Credentials saved but could not connect to Forge AI. Please try again.']);
    }
});

function forge_ai_send_credentials($token, $credentials, $username) {
    $site_url = get_site_url();
    $response = wp_remote_post('https://forge-ai-six-psi.vercel.app/api/store-credentials', [
        'body' => json_encode([
            'token' => $token,
            'site_url' => $site_url,
            'credentials' => $credentials,
            'username' => $username
        ]),
        'headers' => ['Content-Type' => 'application/json'],
        'timeout' => 15,
        'blocking' => true
    ]);
    
    if (is_wp_error($response)) return false;
    $body = json_decode(wp_remote_retrieve_body($response), true);
    return isset($body['success']) && $body['success'];
}

// ── AJAX: DISABLE AUTO-FIX ───────────────────────────────
add_action('wp_ajax_forge_ai_disable_autofix', function() {
    check_ajax_referer('forge_ai_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Permission denied.']);
        return;
    }
    update_option('forge_ai_auto_fix', '0');
    delete_option('forge_ai_app_password');
    wp_send_json_success(['message' => 'Auto-fix disabled.']);
});

// ── REGISTER SITE WHEN SETTINGS SAVED ────────────────────
add_action('updated_option', function($option_name, $old_value, $new_value) {
    if ($option_name !== 'forge_ai_token') return;
    if (empty($new_value) || $new_value === $old_value) return;
    
    // Register this WordPress site with Forge AI for daily monitoring
    $site_url = get_site_url();
    $site_name = get_bloginfo('name') ?: $site_url;
    $token = sanitize_text_field($new_value);
    
    wp_remote_post('https://forge-ai-six-psi.vercel.app/api/register-site', [
        'body' => json_encode([
            'token' => $token,
            'url' => $site_url,
            'name' => $site_name,
            'platform' => 'wordpress'
        ]),
        'headers' => ['Content-Type' => 'application/json'],
        'timeout' => 10,
        'blocking' => false
    ]);
    
    error_log('Forge AI: Registered site ' . $site_url . ' for monitoring');
}, 10, 3);

add_action('admin_init', function() {
    register_setting('forge_ai', 'forge_ai_token');
    register_setting('forge_ai', 'forge_ai_anthropic_key');
    register_setting('forge_ai', 'forge_ai_alerts');
    register_setting('forge_ai', 'forge_ai_auto_fix');
});

add_action('admin_menu', function() {
    add_menu_page('Forge AI', 'Forge AI', 'manage_options', 'forge-ai', 'forge_ai_page', 'dashicons-visibility', 30);
});

// ── ENQUEUE GUTENBERG SIDEBAR ─────────────────────────────
add_action('enqueue_block_editor_assets', function() {
    $token = get_option('forge_ai_token', '');
    $has_fix = !empty(get_option('forge_ai_anthropic_key', ''));
    $alerts = get_option('forge_ai_alerts', '1');
    if (empty($token) || $alerts !== '1') return;

    wp_enqueue_script(
        'forge-ai-sidebar',
        plugins_url('sidebar.js', __FILE__),
        ['wp-plugins', 'wp-editor', 'wp-edit-post', 'wp-element', 'wp-components', 'wp-data', 'wp-blocks'],
        '2.0.0',
        true
    );

    wp_localize_script('forge-ai-sidebar', 'forgeAiData', [
        'token' => $token,
        'hasFix' => $has_fix,
        'anthropicKey' => get_option('forge_ai_anthropic_key', ''),
        'postId' => get_the_ID(),
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('forge_ai_nonce'),
        'endpoint' => 'https://forge-ai-six-psi.vercel.app/api/realtime-check'
    ]);

    wp_enqueue_style(
        'forge-ai-sidebar-style',
        plugins_url('sidebar.css', __FILE__),
        [],
        '2.0.0'
    );
});

// ── AJAX: APPLY FIX ───────────────────────────────────────
add_action('wp_ajax_forge_ai_fix', 'forge_ai_apply_fix');
function forge_ai_apply_fix() {
    check_ajax_referer('forge_ai_nonce', 'nonce');

    $issue_type = sanitize_text_field($_POST['issue_type'] ?? '');
    $post_id = intval($_POST['post_id'] ?? 0);
    $extra_context = sanitize_textarea_field($_POST['context'] ?? '');
    $anthropic_key = get_option('forge_ai_anthropic_key', '');

    if (empty($anthropic_key)) {
        wp_send_json_error(['message' => 'Add your Anthropic API key in Forge AI settings to use auto-fix.']);
        return;
    }

    if (!$post_id || !current_user_can('edit_post', $post_id)) {
        wp_send_json_error(['message' => 'Permission denied.']);
        return;
    }

    $post = get_post($post_id);
    $page_content = wp_strip_all_tags($post->post_content);
    $page_title = $post->post_title;
    $page_url = get_permalink($post_id);

    if (!empty($extra_context) && $extra_context !== $page_title) {
        $page_content = $extra_context . "\n\n" . $page_content;
    }

    $system = "You are an SEO expert writing fixes for a WordPress website. Never use the word 'I' or refer to yourself. Never say you cannot see content. Always write specific, professional copy. Return only the requested content with no explanation.";

    if ($issue_type === 'meta_description') {
        $sample = !empty($page_content) ? substr($page_content, 0, 2000) : "Use the page title to write the description.";
        $prompt = "Write a meta description for this webpage.\nRules: 120-160 characters, professional tone, no first person, include a benefit or call to action.\nReturn ONLY the meta description text.\n\nPage Title: {$page_title}\nPage URL: {$page_url}\nContent: {$sample}";
    } elseif ($issue_type === 'page_title') {
        $prompt = "Rewrite this page title to under 60 characters.\nRules: keep the meaning, include key keywords, professional tone, no first person.\nReturn ONLY the new title.\n\nCurrent: {$page_title}";
    } elseif ($issue_type === 'alt_text') {
        $image_src = sanitize_text_field($_POST['image_src'] ?? '');
        $filename = preg_replace('/[^a-zA-Z0-9\s]/', ' ', pathinfo(basename(parse_url($image_src, PHP_URL_PATH)), PATHINFO_FILENAME));
        $prompt = "Write alt text for an image.\nRules: under 125 characters, descriptive and specific, professional tone, no first person.\nReturn ONLY the alt text.\n\nFilename: {$filename}\nPage: {$page_title}\nContext: " . substr($page_content, 0, 600);
    } else {
        wp_send_json_error(['message' => 'Unknown issue type.']);
        return;
    }

    $response = wp_remote_post('https://api.anthropic.com/v1/messages', [
        'headers' => [
            'Content-Type' => 'application/json',
            'x-api-key' => $anthropic_key,
            'anthropic-version' => '2023-06-01'
        ],
        'body' => json_encode([
            'model' => 'claude-haiku-4-5-20251001',
            'max_tokens' => 300,
            'system' => $system,
            'messages' => [['role' => 'user', 'content' => $prompt]]
        ]),
        'timeout' => 30
    ]);

    if (is_wp_error($response)) {
        wp_send_json_error(['message' => 'API error: ' . $response->get_error_message()]);
        return;
    }

    // Allow fix text override (for browser-generated fixes like alt text)
    $fix_text_override = sanitize_text_field($_POST['fix_text_override'] ?? '');
    if (!empty($fix_text_override)) {
        $fix_text = $fix_text_override;
    } else {
        $body = json_decode(wp_remote_retrieve_body($response), true);
        $fix_text = trim($body['content'][0]['text'] ?? '');
        if (empty($fix_text)) {
            wp_send_json_error(['message' => 'Could not generate fix. Try adding more context.']);
            return;
        }
    }

    // Apply fix
    if ($issue_type === 'meta_description') {
        if (defined('WPSEO_VERSION')) {
            update_post_meta($post_id, '_yoast_wpseo_metadesc', $fix_text);
        }
        update_post_meta($post_id, '_forge_meta_description', $fix_text);
    } elseif ($issue_type === 'page_title') {
        wp_update_post(['ID' => $post_id, 'post_title' => $fix_text]);
    } elseif ($issue_type === 'alt_text') {
        $image_src = sanitize_text_field($_POST['image_src'] ?? '');
        $attachment_id = attachment_url_to_postid($image_src);
        if ($attachment_id) {
            update_post_meta($attachment_id, '_wp_attachment_image_alt', $fix_text);
        }
    }

    wp_send_json_success(['fix_text' => $fix_text]);
}

// ── AJAX: SAVE ALT TEXT ──────────────────────────────────
add_action('wp_ajax_forge_ai_save_alt', function() {
    check_ajax_referer('forge_ai_nonce', 'nonce');
    
    $image_src = sanitize_text_field($_POST['image_src'] ?? '');
    $alt_text = sanitize_text_field($_POST['alt_text'] ?? '');
    
    if (empty($image_src) || empty($alt_text)) {
        wp_send_json_error(['message' => 'Missing data']);
        return;
    }
    
    // Try to find attachment by URL
    $attachment_id = attachment_url_to_postid($image_src);
    
    // Also try without query string
    if (!$attachment_id) {
        $clean_url = strtok($image_src, '?');
        $attachment_id = attachment_url_to_postid($clean_url);
    }
    
    if ($attachment_id) {
        update_post_meta($attachment_id, '_wp_attachment_image_alt', $alt_text);
        wp_send_json_success(['message' => 'Alt text saved', 'attachment_id' => $attachment_id]);
    } else {
        // Store in a transient keyed by URL as fallback
        set_transient('forge_ai_alt_' . md5($image_src), $alt_text, DAY_IN_SECONDS);
        wp_send_json_success(['message' => 'Alt text queued', 'attachment_id' => 0]);
    }
});

// ── ADMIN PAGE ────────────────────────────────────────────
function forge_ai_page() {
    $token = get_option('forge_ai_token', '');
    $anthropic_key = get_option('forge_ai_anthropic_key', '');
    $connected = !empty($token);
    ?>
    <div class="wrap">
    <style>
    .fw{background:#0c0c0d;border-radius:12px;padding:24px;max-width:580px;margin-top:20px}
    .fh{display:flex;align-items:center;gap:12px;margin-bottom:20px;padding-bottom:16px;border-bottom:1px solid rgba(255,255,255,.08)}
    .fi{width:36px;height:36px;background:#ff6b35;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:800;color:#fff}
    .ft{color:#f0f0f2;font-size:1rem;font-weight:700;margin:0}
    .fs{color:#9090a0;font-size:.78rem;margin:2px 0 0}
    .fst{display:inline-flex;align-items:center;gap:5px;font-size:.72rem;padding:3px 10px;border-radius:100px;margin-left:auto}
    .son{background:rgba(34,201,122,.1);color:#22c97a}
    .soff{background:rgba(107,107,120,.1);color:#9090a0}
    .ff{margin-bottom:14px}
    .ff label{display:block;color:#9090a0;font-size:.68rem;text-transform:uppercase;letter-spacing:.08em;margin-bottom:5px}
    .ff input{width:100%;background:#1a1a1d;border:1px solid rgba(255,255,255,.1);border-radius:6px;padding:8px 12px;color:#f0f0f2;font-size:.82rem;font-family:monospace}
    .ff input:focus{border-color:#ff6b35;outline:none}
    .fb{background:#ff6b35;color:#fff;border:none;padding:10px 20px;border-radius:6px;font-size:.85rem;font-weight:700;cursor:pointer;margin-top:6px}
    .feat{display:flex;gap:10px;padding:10px;background:#1a1a1d;border-radius:8px;margin-bottom:8px;margin-top:16px}
    .fc{color:#22c97a}
    .fn{color:#f0f0f2;font-size:.82rem;font-weight:600}
    .fd{color:#9090a0;font-size:.7rem;margin-top:1px}
    </style>
    <div class="fw">
      <div class="fh">
        <div class="fi">F</div>
        <div><div class="ft">Forge AI — Website Intelligence</div><div class="fs">A product of Werdel Global Systems · v2.0</div></div>
        <span class="fst <?php echo $connected?'son':'soff';?>"><?php echo $connected?'● Connected':'○ Not connected';?></span>
      </div>
      <form method="post" action="options.php">
        <?php settings_fields('forge_ai');?>
        <div class="ff"><label>Forge AI Token</label><input type="text" name="forge_ai_token" value="<?php echo esc_attr($token);?>" placeholder="fat_xxxxxxxxxxxxxxxx_..."><p style="color:#6b6b78;font-size:.7rem;margin:4px 0 0">Find in your Forge AI dashboard</p></div>
        <div class="ff"><label>Anthropic API Key <span style="color:#ff6b35">(for AI auto-fix)</span></label><input type="password" name="forge_ai_anthropic_key" value="<?php echo esc_attr($anthropic_key);?>" placeholder="sk-ant-..."><p style="color:#6b6b78;font-size:.7rem;margin:4px 0 0">Get from console.anthropic.com</p></div>
        <div class="ff"><label style="display:flex;align-items:center;gap:8px;cursor:pointer"><input type="checkbox" name="forge_ai_alerts" value="1" <?php checked(get_option('forge_ai_alerts','1'),'1');?> style="width:auto"><span style="color:#f0f0f2;font-size:.85rem">Enable real-time building alerts</span></label></div>
        <?php submit_button('Save & Connect','primary','submit',false,['class'=>'fb']);?>
      </form>
      <?php if($connected):?>
      <div class="feat"><span class="fc">✓</span><div><div class="fn">Live sidebar analysis</div><div class="fd">Issues appear in the editor sidebar as you build — no saving needed</div></div></div>
      <div class="feat"><span class="fc">✓</span><div><div class="fn">AI auto-fix</div><div class="fd">Click Fix Now on any issue to apply an AI-generated fix instantly</div></div></div>
      <div class="feat"><span class="fc">✓</span><div><div class="fn">Daily automated scans</div><div class="fd">Full 5-module scan sent to your Forge AI dashboard every day</div></div></div>

      <?php
      $auto_fix_enabled = !empty(get_option('forge_ai_app_password', ''));
      $auto_fix_setting = get_option('forge_ai_auto_fix', '1');
      ?>
      <div style="margin-top:16px;padding-top:16px;border-top:1px solid rgba(255,255,255,.08)">
        <div style="color:#9090a0;font-size:.68rem;text-transform:uppercase;letter-spacing:.08em;margin-bottom:10px">Autonomous Maintenance</div>
        <div style="background:#1a1a1d;border-radius:8px;padding:12px;margin-bottom:10px">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
            <div style="color:#f0f0f2;font-size:.82rem;font-weight:600">Auto-fix</div>
            <span style="font-size:.72rem;padding:2px 8px;border-radius:4px;<?php echo $auto_fix_enabled && $auto_fix_setting === '1' ? 'background:rgba(34,201,122,.1);color:#22c97a' : 'background:rgba(107,107,120,.1);color:#9090a0'; ?>">
              <?php echo $auto_fix_enabled && $auto_fix_setting === '1' ? '● Active' : '○ Not enabled'; ?>
            </span>
          </div>
          <div style="color:#9090a0;font-size:.72rem;margin-bottom:10px">When enabled Forge AI automatically fixes meta descriptions, alt text, and page titles on this site.</div>
          <?php if($auto_fix_enabled): ?>
            <div style="display:flex;gap:8px">
              <button type="button" id="forge-disable-autofix" onclick="forgeDisableAutofix()" style="background:#1a1a1d;border:1px solid rgba(255,255,255,.1);color:#9090a0;padding:6px 14px;border-radius:6px;font-size:.78rem;cursor:pointer">Disable Auto-fix</button>
            </div>
          <?php else: ?>
            <button type="button" id="forge-enable-autofix" onclick="forgeEnableAutofix()" style="background:#ff6b35;color:#fff;border:none;padding:8px 18px;border-radius:6px;font-size:.82rem;font-weight:700;cursor:pointer;width:100%">Enable Auto-fix →</button>
          <?php endif; ?>
          <div id="forge-autofix-msg" style="margin-top:8px;font-size:.78rem;display:none"></div>
        </div>
      </div>

      <script>
      function forgeEnableAutofix() {
        var btn = document.getElementById('forge-enable-autofix');
        var msg = document.getElementById('forge-autofix-msg');
        btn.textContent = 'Enabling...';
        btn.disabled = true;
        msg.style.display = 'none';

        jQuery.post(ajaxurl, {
          action: 'forge_ai_enable_autofix',
          nonce: '<?php echo wp_create_nonce("forge_ai_nonce"); ?>'
        }, function(response) {
          if (response.success) {
            msg.style.color = '#22c97a';
            msg.textContent = '✓ ' + response.data.message;
            msg.style.display = 'block';
            setTimeout(function() { location.reload(); }, 1500);
          } else {
            msg.style.color = '#ff6b6b';
            msg.textContent = '✗ ' + (response.data ? response.data.message : 'Error enabling auto-fix');
            msg.style.display = 'block';
            btn.textContent = 'Enable Auto-fix →';
            btn.disabled = false;
          }
        });
      }

      function forgeDisableAutofix() {
        if (!confirm('Disable auto-fix? Forge AI will no longer automatically fix issues on this site.')) return;
        jQuery.post(ajaxurl, {
          action: 'forge_ai_disable_autofix',
          nonce: '<?php echo wp_create_nonce("forge_ai_nonce"); ?>'
        }, function(response) {
          if (response.success) location.reload();
        });
      }
      </script>
      <?php endif;?>
    </div>
    </div>
    <?php
}

// ── FRONTEND MONITORING (for published pages) ─────────────
add_action('wp_footer', function() {
    $token = get_option('forge_ai_token', '');
    if (empty($token) || is_admin()) return;
    ?>
    <script>
    (function(){
      var token='<?php echo esc_js($token);?>';
      var endpoint='https://forge-ai-six-psi.vercel.app/api/realtime-check';
      function checks(){
        var issues=[];
        var m=document.querySelector('meta[name="description"]');
        if(!m||!m.content||m.content.trim().length<10) issues.push({name:'Missing meta description',severity:'critical'});
        if(!document.querySelectorAll('h1').length) issues.push({name:'No H1 heading',severity:'critical'});
        var imgs=document.querySelectorAll('img');
        var noAlt=0;
        [].forEach.call(imgs,function(i){
          var s=i.src||'';
          if(s.indexOf('wp-includes')>-1||s.indexOf('gravatar')>-1||(i.width>0&&i.width<50)) return;
          if(!i.getAttribute('alt')||!i.getAttribute('alt').trim()) noAlt++;
        });
        if(noAlt) issues.push({name:noAlt+' image(s) missing alt text',severity:noAlt>2?'critical':'high'});
        return issues;
      }
      window.addEventListener('load',function(){
        setTimeout(function(){
          var issues=checks();
          if(issues.length) fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token:token,url:window.location.href,pageTitle:document.title,issues:issues,timestamp:new Date().toISOString()})}).catch(function(){});
        },2000);
      });
    })();
    </script>
    <?php
});
