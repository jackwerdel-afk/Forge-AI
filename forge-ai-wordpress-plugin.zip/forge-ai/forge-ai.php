<?php
/**
 * Plugin Name: Forge AI — Website Intelligence
 * Plugin URI: https://forge-ai-six-psi.vercel.app
 * Description: Real-time building alerts, automated SEO fixes, and continuous monitoring. A product of Werdel Global Systems.
 * Version: 1.1.0
 * Author: Werdel Global Systems
 */

if (!defined('ABSPATH')) exit;

// ── ACTIVATION ────────────────────────────────────────────
register_activation_hook(__FILE__, function() {
    add_option('forge_ai_token', '');
    add_option('forge_ai_alerts', '1');
    add_option('forge_ai_auto_fix', '1');
});

// ── SETTINGS ──────────────────────────────────────────────
add_action('admin_init', function() {
    register_setting('forge_ai', 'forge_ai_token', ['sanitize_callback' => 'sanitize_text_field']);
    register_setting('forge_ai', 'forge_ai_alerts', ['sanitize_callback' => 'sanitize_text_field']);
    register_setting('forge_ai', 'forge_ai_auto_fix', ['sanitize_callback' => 'sanitize_text_field']);
});

// ── ADMIN MENU ────────────────────────────────────────────
add_action('admin_menu', function() {
    add_menu_page('Forge AI', 'Forge AI', 'manage_options', 'forge-ai', 'forge_ai_page', 'dashicons-visibility', 30);
});

// ── ADMIN PAGE ────────────────────────────────────────────
function forge_ai_page() {
    $token = get_option('forge_ai_token', '');
    $alerts = get_option('forge_ai_alerts', '1');
    $auto_fix = get_option('forge_ai_auto_fix', '1');
    $connected = !empty($token);
    ?>
    <div class="wrap">
      <style>
        .forge-wrap{background:#0c0c0d;border-radius:12px;padding:24px;max-width:600px;margin-top:20px}
        .forge-header{display:flex;align-items:center;gap:12px;margin-bottom:20px;padding-bottom:16px;border-bottom:1px solid rgba(255,255,255,.08)}
        .forge-icon{width:36px;height:36px;background:#ff6b35;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:800;color:#fff;flex-shrink:0}
        .forge-title{color:#f0f0f2;font-size:1.1rem;font-weight:700;margin:0}
        .forge-sub{color:#9090a0;font-size:.8rem;margin:2px 0 0}
        .forge-status{display:inline-flex;align-items:center;gap:6px;font-size:.75rem;padding:3px 10px;border-radius:100px;margin-left:auto}
        .status-on{background:rgba(34,201,122,.1);color:#22c97a}
        .status-off{background:rgba(107,107,120,.1);color:#9090a0}
        .forge-field{margin-bottom:16px}
        .forge-field label{display:block;color:#9090a0;font-size:.72rem;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px}
        .forge-field input[type=text]{width:100%;background:#1a1a1d;border:1px solid rgba(255,255,255,.1);border-radius:6px;padding:9px 12px;color:#f0f0f2;font-size:.85rem}
        .forge-field input[type=text]:focus{border-color:#ff6b35;outline:none}
        .forge-btn{background:#ff6b35;color:#fff;border:none;padding:10px 20px;border-radius:6px;font-size:.85rem;font-weight:700;cursor:pointer}
        .forge-feature{display:flex;align-items:center;gap:10px;padding:10px;background:#1a1a1d;border-radius:8px;margin-bottom:8px}
        .forge-feature-text{color:#f0f0f2;font-size:.82rem;font-weight:600}
        .forge-feature-sub{color:#9090a0;font-size:.72rem;margin-top:1px}
        .forge-check{color:#22c97a;font-size:1rem}
      </style>
      <div class="forge-wrap">
        <div class="forge-header">
          <div class="forge-icon">F</div>
          <div>
            <div class="forge-title">Forge AI — Website Intelligence</div>
            <div class="forge-sub">A product of Werdel Global Systems</div>
          </div>
          <span class="forge-status <?php echo $connected ? 'status-on' : 'status-off'; ?>">
            <?php echo $connected ? '● Connected' : '○ Not connected'; ?>
          </span>
        </div>

        <form method="post" action="options.php">
          <?php settings_fields('forge_ai'); ?>
          
          <div class="forge-field">
            <label>Your Forge AI Token</label>
            <input type="text" name="forge_ai_token" value="<?php echo esc_attr($token); ?>" placeholder="fat_xxxxxxxxxxxxxxxx_...">
            <p style="color:#6b6b78;font-size:.72rem;margin:6px 0 0">Find your token in your Forge AI dashboard</p>
          </div>

          <div class="forge-field">
            <label style="display:flex;align-items:center;gap:8px;cursor:pointer">
              <input type="checkbox" name="forge_ai_alerts" value="1" <?php checked($alerts, '1'); ?> style="width:auto">
              <span style="color:#f0f0f2;font-size:.85rem">Enable real-time building alerts</span>
            </label>
          </div>

          <div class="forge-field">
            <label style="display:flex;align-items:center;gap:8px;cursor:pointer">
              <input type="checkbox" name="forge_ai_auto_fix" value="1" <?php checked($auto_fix, '1'); ?> style="width:auto">
              <span style="color:#f0f0f2;font-size:.85rem">Enable autonomous auto-fix</span>
            </label>
          </div>

          <?php submit_button('Save & Connect', 'primary', 'submit', false, ['class' => 'forge-btn', 'style' => 'margin-top:8px']); ?>
        </form>

        <?php if ($connected): ?>
        <div style="margin-top:20px;padding-top:16px;border-top:1px solid rgba(255,255,255,.08)">
          <div style="color:#9090a0;font-size:.7rem;text-transform:uppercase;letter-spacing:.08em;margin-bottom:10px">Active Features</div>
          <div class="forge-feature"><span class="forge-check">✓</span><div><div class="forge-feature-text">Real-time building alerts</div><div class="forge-feature-sub">Popup alerts while editing pages</div></div></div>
          <div class="forge-feature"><span class="forge-check">✓</span><div><div class="forge-feature-text">Auto-fix image alt text</div><div class="forge-feature-sub">AI-generated alt text on save</div></div></div>
          <div class="forge-feature"><span class="forge-check">✓</span><div><div class="forge-feature-text">Meta description monitoring</div><div class="forge-feature-sub">Alerts for missing meta descriptions</div></div></div>
          <div class="forge-feature"><span class="forge-check">✓</span><div><div class="forge-feature-text">Daily automated scans</div><div class="forge-feature-sub">Full 5-module scan every day</div></div></div>
        </div>
        <?php endif; ?>
      </div>
    </div>
    <?php
}

// ── INJECT MONITORING SCRIPT ──────────────────────────────
add_action('wp_footer', function() {
    $token = get_option('forge_ai_token', '');
    $alerts = get_option('forge_ai_alerts', '1');
    if (empty($token) || $alerts !== '1') return;
    ?>
    <script>
    // Forge AI Real-time Monitor
    (function() {
      var token = '<?php echo esc_js($token); ?>';
      var endpoint = 'https://forge-ai-six-psi.vercel.app/api/realtime-check';
      var shown = false;

      function runChecks() {
        var issues = [];

        // Check meta description
        var meta = document.querySelector('meta[name="description"]');
        if (!meta || !meta.content || meta.content.trim().length < 10) {
          issues.push({name:'Missing meta description',description:'This page has no meta description.',severity:'critical',fix:'Add a meta description of 120-160 characters.'});
        }

        // Check H1
        var h1s = document.querySelectorAll('h1');
        if (h1s.length === 0) {
          issues.push({name:'No H1 heading',description:'Every page needs exactly one H1.',severity:'critical',fix:'Add an H1 heading to this page.'});
        } else if (h1s.length > 1) {
          issues.push({name:'Multiple H1 tags',description:'Found ' + h1s.length + ' H1 tags. Use only one.',severity:'high',fix:'Keep only one H1 tag.'});
        }

        // Check images
        var imgs = document.querySelectorAll('img');
        var noAlt = [].filter.call(imgs, function(img){ return !img.getAttribute('alt') || img.getAttribute('alt').trim() === ''; });
        if (noAlt.length > 0) {
          issues.push({name: noAlt.length + ' image(s) missing alt text',description:'Images without alt text hurt SEO and accessibility.',severity: noAlt.length > 2 ? 'critical' : 'high',fix:'Add descriptive alt text to every image.'});
        }

        // Check title
        if (!document.title || document.title.trim().length < 5) {
          issues.push({name:'Missing page title',description:'This page has no title tag.',severity:'critical',fix:'Add a descriptive page title.'});
        }

        return issues;
      }

      function showPopup(issues) {
        var existing = document.getElementById('forge-ai-popup');
        if (existing) existing.remove();
        if (issues.length === 0) return;

        var critical = issues.filter(function(i){ return i.severity === 'critical'; }).length;
        var popup = document.createElement('div');
        popup.id = 'forge-ai-popup';
        popup.style.cssText = 'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);z-index:999999;width:460px;max-width:90vw;background:#131315;border:1px solid rgba(255,107,53,.4);border-radius:16px;padding:24px;box-shadow:0 24px 60px rgba(0,0,0,.7);font-family:-apple-system,sans-serif';

        popup.innerHTML = '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">' +
          '<div style="display:flex;align-items:center;gap:10px">' +
          '<div style="width:28px;height:28px;background:#ff6b35;border-radius:6px;display:flex;align-items:center;justify-content:center;font-weight:800;color:#fff;font-size:13px">F</div>' +
          '<span style="color:#f0f0f2;font-weight:700;font-size:14px">Forge AI — ' + issues.length + ' issue' + (issues.length>1?'s':'') + ' found</span>' +
          '</div>' +
          '<button onclick="document.getElementById(\'forge-ai-popup\').remove()" style="background:transparent;border:none;color:#9090a0;cursor:pointer;font-size:18px;line-height:1">✕</button>' +
          '</div>' +
          (critical > 0 ? '<div style="background:rgba(255,59,59,.08);border:1px solid rgba(255,59,59,.2);border-radius:6px;padding:8px 12px;margin-bottom:12px;font-size:12px;color:#ff8080">⚠ ' + critical + ' critical issue' + (critical>1?'s':'') + ' need immediate attention</div>' : '') +
          '<div style="max-height:240px;overflow-y:auto">' +
          issues.map(function(i) {
            var color = i.severity==='critical'?'#ff6b6b':i.severity==='high'?'#f5a623':'#4d9fff';
            var bg = i.severity==='critical'?'rgba(255,59,59,.12)':i.severity==='high'?'rgba(245,166,35,.12)':'rgba(77,159,255,.1)';
            return '<div style="background:#1a1a1d;border-radius:8px;padding:10px 12px;margin-bottom:8px">' +
              '<div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">' +
              '<span style="font-size:10px;font-weight:700;padding:1px 7px;border-radius:3px;background:'+bg+';color:'+color+'">'+i.severity.toUpperCase()+'</span>' +
              '<span style="color:#f0f0f2;font-size:12px;font-weight:600">'+i.name+'</span>' +
              '</div>' +
              '<div style="color:#9090a0;font-size:11px;line-height:1.5">'+i.fix+'</div>' +
              '</div>';
          }).join('') +
          '</div>' +
          '<div style="display:flex;justify-content:space-between;align-items:center;margin-top:12px">' +
          '<a href="https://forge-ai-six-psi.vercel.app/forge-ai-dashboard.html" target="_blank" style="font-size:11px;color:#ff6b35;text-decoration:none">View in dashboard →</a>' +
          '<button onclick="document.getElementById(\'forge-ai-popup\').remove()" style="background:#ff6b35;color:#fff;border:none;padding:7px 16px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer">Got it</button>' +
          '</div>';

        // Dark overlay
        var overlay = document.createElement('div');
        overlay.id = 'forge-ai-overlay';
        overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:999998;backdrop-filter:blur(2px)';
        overlay.onclick = function(){ popup.remove(); overlay.remove(); };

        document.body.appendChild(overlay);
        document.body.appendChild(popup);

        // Send to Forge AI
        fetch(endpoint, {
          method: 'POST',
          headers: {'Content-Type':'application/json'},
          body: JSON.stringify({token:token, url:window.location.href, pageTitle:document.title, issues:issues, timestamp:new Date().toISOString()})
        }).catch(function(){});
      }

      // Check after page loads
      window.addEventListener('load', function() {
        setTimeout(function() {
          var issues = runChecks();
          if (issues.length > 0) showPopup(issues);
        }, 1500);
      });

      // Check when WordPress saves (admin bar save button)
      document.addEventListener('click', function(e) {
        if (e.target && (e.target.id === 'publish' || e.target.classList.contains('editor-post-publish-button') || e.target.id === 'save-post')) {
          setTimeout(function() {
            var issues = runChecks();
            if (issues.length > 0) showPopup(issues);
          }, 2000);
        }
      });

    })();
    </script>
    <?php
});

// ── PAGE SAVE HOOK ────────────────────────────────────────
add_action('save_post', function($post_id, $post, $update) {
    $token = get_option('forge_ai_token', '');
    if (empty($token)) return;
    if (wp_is_post_revision($post_id) || $post->post_status !== 'publish') return;

    $issues = [];
    $content = $post->post_content;

    $meta_desc = get_post_meta($post_id, '_yoast_wpseo_metadesc', true);
    if (empty($meta_desc)) {
        $issues[] = ['name'=>'Missing meta description','description'=>'No meta description set.','severity'=>'critical','fix'=>'Add a meta description of 120-160 characters.'];
    }

    preg_match_all('/<img[^>]+>/i', $content, $img_matches);
    $no_alt = 0;
    foreach ($img_matches[0] as $img) {
        if (!preg_match('/alt=["\'][^"\']+["\']/i', $img)) $no_alt++;
    }
    if ($no_alt > 0) {
        $issues[] = ['name'=>$no_alt.' image(s) missing alt text','description'=>$no_alt.' images have no alt text.','severity'=>$no_alt>2?'critical':'high','fix'=>'Add alt text to every image.'];
    }

    if (empty($issues)) return;

    wp_remote_post('https://forge-ai-six-psi.vercel.app/api/realtime-check', [
        'body' => json_encode(['token'=>$token,'url'=>get_permalink($post_id),'pageTitle'=>$post->post_title,'issues'=>$issues,'timestamp'=>date('c')]),
        'headers' => ['Content-Type'=>'application/json'],
        'timeout' => 10,
        'blocking' => false
    ]);
}, 10, 3);
