(function() {
  var el = wp.element.createElement;
  var Fragment = wp.element.Fragment;
  var useState = wp.element.useState;
  var useEffect = wp.element.useEffect;
  var useRef = wp.element.useRef;
  var PanelBody = wp.components.PanelBody;
  var registerPlugin = wp.plugins.registerPlugin;
  // Support both old and new WordPress API
  var PluginSidebar = (wp.editor && wp.editor.PluginSidebar) || wp.editPost.PluginSidebar;
  var PluginSidebarMoreMenuItem = (wp.editor && wp.editor.PluginSidebarMoreMenuItem) || wp.editPost.PluginSidebarMoreMenuItem;
  var useSelect = wp.data.useSelect;

  var data = window.forgeAiData || {};

  function runChecks(content, title, metaDesc) {
    var issues = [];

    // Check meta description
    if (!metaDesc || metaDesc.trim().length < 10) {
      issues.push({ type:'meta_description', severity:'critical', name:'Missing meta description', desc:'No meta description set for this page.', fixable:true, imageSrc:'' });
    } else if (metaDesc.length > 160) {
      issues.push({ type:'meta_description', severity:'medium', name:'Meta description too long ('+metaDesc.length+' chars)', desc:'Keep meta descriptions under 160 characters.', fixable:true, imageSrc:'' });
    }

    // Check page title
    if (!title || title.trim().length < 3) {
      issues.push({ type:'page_title', severity:'critical', name:'Missing page title', desc:'A descriptive title is required for SEO.', fixable:true, imageSrc:'' });
    } else if (title.length > 60) {
      issues.push({ type:'page_title', severity:'medium', name:'Page title too long ('+title.length+' chars)', desc:'Search engines truncate titles over 60 characters.', fixable:true, imageSrc:'' });
    }

    // Check headings in Gutenberg block content
    // Gutenberg uses <!-- wp:heading --> blocks and <h1> tags
    var h1Count = (content.match(/<!-- wp:heading {"level":1}/gi) || []).length +
                  (content.match(/<h1[\s>]/gi) || []).length;
    
    if (h1Count === 0) {
      issues.push({ type:'heading', severity:'critical', name:'No H1 heading found', desc:'Pages should have exactly one H1 heading.', fixable:false, imageSrc:'' });
    } else if (h1Count > 1) {
      issues.push({ type:'heading', severity:'high', name:'Multiple H1 headings ('+h1Count+')', desc:'Remove extra H1 headings and keep only one.', fixable:false, imageSrc:'' });
    }

    // Check images - Gutenberg uses <!-- wp:image --> blocks
    var imgBlocks = content.match(/<!-- wp:image[^>]*-->/gi) || [];
    var imgTags = content.match(/<img[^>]+>/gi) || [];
    
    imgTags.forEach(function(img) {
      if (img.indexOf('wp-includes') > -1 || img.indexOf('gravatar') > -1) return;
      var hasAlt = img.match(/alt=["'][^"']+["']/i);
      if (!hasAlt) {
        var srcMatch = img.match(/src=["']([^"']+)["']/i);
        var src = srcMatch ? srcMatch[1] : '';
        issues.push({ type:'alt_text', severity:'high', name:'Image missing alt text', desc:'This image has no alt text set.', fixable:true, imageSrc:src });
      }
    });

    // Check if content is empty
    var textContent = content.replace(/<!--[\s\S]*?-->/g, '').replace(/<[^>]+>/g, '').trim();
    if (textContent.length < 50 && content.length < 200) {
      issues.push({ type:'content', severity:'medium', name:'Page has very little content', desc:'Add more content to improve SEO rankings.', fixable:false, imageSrc:'' });
    }

    return issues;
  }

  function IssueCard(props) {
    var issue = props.issue;
    var postId = props.postId;
    var state = useState('idle'); // idle, loading, success, context
    var status = state[0];
    var setStatus = state[1];
    var fixText = useState('')[0];
    var setFixText = state[1];
    var contextText = useState('')[0];
    var setContextText = useState('')[1];
    var contextRef = useRef('');

    var statusState = useState('idle');
    var currentStatus = statusState[0];
    var setCurrentStatus = statusState[1];
    var resultText = useState('')[0];
    var setResultText = useState('')[1];
    var contextVal = useState('')[0];
    var setContextVal = useState('')[1];

    function doFix(extraCtx) {
      setCurrentStatus('loading');
      var formData = new FormData();
      formData.append('action', 'forge_ai_fix');
      formData.append('nonce', data.nonce);
      formData.append('issue_type', issue.type);
      formData.append('post_id', postId);
      formData.append('context', extraCtx || '');
      if (issue.imageSrc) formData.append('image_src', issue.imageSrc);

      fetch(data.ajaxUrl, { method: 'POST', body: formData })
        .then(function(r) { return r.json(); })
        .then(function(res) {
          if (res.success) {
            setCurrentStatus('success');
            setResultText(res.data.fix_text || '');
          } else {
            setCurrentStatus('context');
          }
        })
        .catch(function() { setCurrentStatus('idle'); });
    }

    var color = issue.severity === 'critical' ? '#ff6b6b' : issue.severity === 'high' ? '#f5a623' : '#4d9fff';

    return el('div', { className: 'forge-ai-issue ' + issue.severity },
      el('span', { className: 'forge-ai-sev ' + issue.severity }, issue.severity.toUpperCase()),
      el('div', { className: 'forge-ai-issue-name' }, issue.name),
      el('div', { className: 'forge-ai-issue-desc' }, issue.desc),

      currentStatus === 'idle' && issue.fixable && data.hasFix &&
        el('button', {
          className: 'forge-ai-fix-btn',
          onClick: function() { doFix(''); }
        }, 'Fix Now →'),

      currentStatus === 'loading' &&
        el('button', { className: 'forge-ai-fix-btn', disabled: true }, 'Fixing...'),

      currentStatus === 'success' &&
        el(Fragment, null,
          el('div', { style: { color: '#22c97a', fontSize: '11px', marginTop: '5px', fontWeight: '600' } }, '✓ Fixed!'),
          el('div', { style: { color: '#9090a0', fontSize: '10px', fontStyle: 'italic', marginTop: '2px' } },
            '"' + resultText.substring(0, 80) + (resultText.length > 80 ? '...' : '') + '"'
          )
        ),

      currentStatus === 'context' &&
        el('div', { className: 'forge-ai-context-area' },
          el('span', { className: 'forge-ai-context-label' },
            issue.type === 'alt_text' ? 'Describe this image briefly:' :
            issue.type === 'meta_description' ? 'Briefly describe this page:' :
            'Add context for a better fix:'
          ),
          el('textarea', {
            placeholder: issue.type === 'alt_text' ? 'e.g. Team photo at company headquarters' : 'e.g. Contact page for a web design agency in Denver',
            onChange: function(e) { setContextVal(e.target.value); },
            style: { width: '100%', background: '#0c0c0d', border: '1px solid rgba(255,107,53,0.3)', borderRadius: '5px', padding: '6px 8px', color: '#f0f0f2', fontSize: '11px', minHeight: '50px', fontFamily: 'inherit', resize: 'vertical' }
          }),
          el('button', {
            className: 'forge-ai-generate-btn',
            onClick: function() {
              var textarea = document.querySelector('.forge-ai-context-area textarea');
              var ctx = textarea ? textarea.value : '';
              if (ctx.trim()) doFix(ctx);
            }
          }, 'Generate & Apply →')
        )
    );
  }

  function ForgeAiPanel() {
    var issues = useState([])[0];
    var setIssues = useState([])[1];
    var checking = useState(true)[0];
    var setChecking = useState(true)[1];

    var postContent = useSelect(function(select) {
      return select('core/editor').getEditedPostAttribute('content') || '';
    });

    var postTitle = useSelect(function(select) {
      return select('core/editor').getEditedPostAttribute('title') || '';
    });

    var metaDesc = useSelect(function(select) {
      var meta = select('core/editor').getEditedPostAttribute('meta') || {};
      return meta._yoast_wpseo_metadesc || meta._forge_meta_description || '';
    });

    var postId = useSelect(function(select) {
      return select('core/editor').getCurrentPostId();
    });

    useEffect(function() {
      setChecking(true);
      var timer = setTimeout(function() {
        var found = runChecks(postContent, postTitle, metaDesc);
        setIssues(found);
        setChecking(false);

        if (found.length > 0 && data.token) {
          fetch(data.endpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              token: data.token,
              url: window.location.href,
              pageTitle: postTitle,
              issues: found,
              timestamp: new Date().toISOString()
            })
          }).catch(function() {});
        }
      }, 800);
      return function() { clearTimeout(timer); };
    }, [postContent, postTitle, metaDesc]);

    return el('div', { className: 'forge-ai-panel' },
      el('div', { className: 'forge-ai-header' },
        el('div', { className: 'forge-ai-icon' }, 'F'),
        el('div', { className: 'forge-ai-title' }, 'Forge AI'),
        el('div', { className: 'forge-ai-live' },
          el('div', { className: 'forge-ai-live-dot' }),
          'Live'
        )
      ),
      el('div', { className: 'forge-ai-body' },
        checking
          ? el('div', { className: 'forge-ai-checking' }, 'Analyzing...')
          : issues.length === 0
          ? el('div', { className: 'forge-ai-clean' },
              el('div', { className: 'forge-ai-clean-icon' }, '✓'),
              'No issues found'
            )
          : issues.map(function(issue, i) {
              return el(IssueCard, {
                key: issue.type + i + issue.imageSrc,
                issue: issue,
                postId: postId
              });
            })
      )
    );
  }

  registerPlugin('forge-ai-sidebar', {
    render: function() {
      return el(Fragment, null,
        el(PluginSidebarMoreMenuItem, { target: 'forge-ai-sidebar' }, 'Forge AI'),
        el(PluginSidebar, {
          name: 'forge-ai-sidebar',
          title: 'Forge AI',
          icon: el('span', { style: { background: '#ff6b35', borderRadius: '4px', padding: '2px 5px', color: '#fff', fontWeight: '800', fontSize: '10px' } }, 'F')
        },
          el(PanelBody, { initialOpen: true },
            el(ForgeAiPanel, null)
          )
        )
      );
    }
  });
})();
