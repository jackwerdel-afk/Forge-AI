<?php
/**
 * Plugin Name: Forge AI — Website Intelligence
 * Plugin URI: https://forge-ai-six-psi.vercel.app
 * Description: Real-time building alerts, AI auto-fix, and continuous monitoring. A product of Werdel Global Systems.
 * Version: 1.2.0
 * Author: Werdel Global Systems
 */

if (!defined('ABSPATH')) exit;

// ── ACTIVATION ────────────────────────────────────────────
register_activation_hook(__FILE__, function() {
    add_option('forge_ai_token', '');
    add_option('forge_ai_anthropic_key', '');
    add_option('forge_ai_alerts', '1');
    add_option('forge_ai_auto_fix', '1');
});

// ── SETTINGS ──────────────────────────────────────────────
add_action('admin_init', function() {
    register_setting('forge_ai', 'forge_ai_token');
    register_setting('forge_ai', 'forge_ai_anthropic_key');
    register_setting('forge_ai', 'forge_ai_alerts');
    register_setting('forge_ai', 'forge_ai_auto_fix');
});

// ── ADMIN MENU ────────────────────────────────────────────
add_action('admin_menu', function() {
    add_menu_page('Forge AI', 'Forge AI', 'manage_options', 'forge-ai', 'forge_ai_page', 'dashicons-visibility', 30);
});

// ── AJAX: GENERATE AND APPLY FIX ─────────────────────────
add_action('wp_ajax_forge_ai_fix', 'forge_ai_apply_fix');
function forge_ai_apply_fix() {
    check_ajax_referer('forge_ai_nonce', 'nonce');
    
    $issue_type = sanitize_text_field($_POST['issue_type'] ?? '');
    $post_id = intval($_POST['post_id'] ?? 0);
    $context = sanitize_textarea_field($_POST['context'] ?? '');
    $anthropic_key = get_option('forge_ai_anthropic_key', '');

    if (empty($anthropic_key)) {
        wp_send_json_error(['message' => 'Please add your Anthropic API key in Forge AI settings.']);
        return;
    }

    if (!$post_id || !current_user_can('edit_post', $post_id)) {
        wp_send_json_error(['message' => 'Permission denied.']);
        return;
    }

    $post = get_post($post_id);
    $page_content = wp_strip_all_tags($post->post_content);
    $page_title = $post->post_title;
    $page_url = get_permalink($post_id);
    
    // Use extra context provided by agency if available
    $extra_context = sanitize_textarea_field($_POST['context'] ?? '');
    if (!empty($extra_context) && $extra_context !== $page_title) {
        $page_content = $extra_context . "

" . $page_content;
    }

    // Build prompt based on issue type
    $prompt = '';
    $fix_applied = '';

    $system = "You are an SEO expert writing fixes for a WordPress website. Never use the word 'I' or refer to yourself. Never say you cannot see content. Always write specific, professional copy based on the information provided. Return only the requested content with no explanation or preamble.";

    if ($issue_type === 'meta_description') {
        $content_sample = !empty($page_content) ? substr($page_content, 0, 2000) : "No content available — use the page title to write the description.";
        $prompt = "Write a meta description for this webpage.\n\nRules:\n- Between 120-160 characters\n- Professional tone, no first person\n- Include a clear benefit or call to action\n- Based on the page title and content below\n- Return ONLY the meta description text, nothing else\n\nPage Title: {$page_title}\nPage URL: {$page_url}\nPage Content: {$content_sample}";
    } elseif ($issue_type === 'page_title') {
        $prompt = "Rewrite this page title to be under 60 characters.\n\nRules:\n- Keep the core meaning\n- Include the most important keywords\n- Professional tone, no first person\n- Return ONLY the new title, nothing else\n\nCurrent title: {$page_title}";
    } elseif ($issue_type === 'alt_text') {
        $image_src = sanitize_text_field($_POST['image_src'] ?? '');
        $filename = basename(parse_url($image_src, PHP_URL_PATH));
        $filename = preg_replace('/[^a-zA-Z0-9\s]/', ' ', pathinfo($filename, PATHINFO_FILENAME));
        $prompt = "Write alt text for an image on this webpage.\n\nRules:\n- Under 125 characters\n- Descriptive and specific\n- Professional tone, no first person\n- Based on the image filename and page context\n- Return ONLY the alt text, nothing else\n\nImage filename: {$filename}\nPage Title: {$page_title}\nPage Context: " . substr($page_content, 0, 800);
    } else {
        wp_send_json_error(['message' => 'Unknown issue type.']);
        return;
    }

    // Call Anthropic API
    $response = wp_remote_post('https://api.anthropic.com/v1/messages', [
        'headers' => [
            'Content-Type' => 'application/json',
            'x-api-key' => $anthropic_key,
            'anthropic-version' => '2023-06-01'
        ],
        'body' => json_encode([
            'model' => 'claude-haiku-4-5-20251001',
            'max_tokens' => 300,
            'system' => $system,
            'messages' => [['role' => 'user', 'content' => $prompt]]
        ]),
        'timeout' => 30
    ]);

    if (is_wp_error($response)) {
        wp_send_json_error(['message' => 'API error: ' . $response->get_error_message()]);
        return;
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);
    $fix_text = trim($body['content'][0]['text'] ?? '');

    if (empty($fix_text)) {
        wp_send_json_error(['message' => 'Could not generate fix. Please try again.']);
        return;
    }

    // Apply the fix
    if ($issue_type === 'meta_description') {
        // Save to Yoast if available, otherwise to post meta
        if (defined('WPSEO_VERSION')) {
            update_post_meta($post_id, '_yoast_wpseo_metadesc', $fix_text);
        } else {
            update_post_meta($post_id, '_forge_ai_meta_desc', $fix_text);
            // Also inject via wp_head if Yoast not available
            update_post_meta($post_id, '_forge_meta_description', $fix_text);
        }
        $fix_applied = 'Meta description set to: "' . $fix_text . '"';
    } elseif ($issue_type === 'page_title') {
        wp_update_post(['ID' => $post_id, 'post_title' => $fix_text]);
        $fix_applied = 'Page title updated to: "' . $fix_text . '"';
    } elseif ($issue_type === 'alt_text') {
        $image_src = sanitize_text_field($_POST['image_src'] ?? '');
        // Find attachment by URL and update alt text
        $attachment_id = attachment_url_to_postid($image_src);
        if ($attachment_id) {
            update_post_meta($attachment_id, '_wp_attachment_image_alt', $fix_text);
        }
        $fix_applied = 'Alt text set to: "' . $fix_text . '"';
    }

    wp_send_json_success([
        'message' => '✓ Fixed! ' . $fix_applied,
        'fix_text' => $fix_text
    ]);
}

// ── ADMIN PAGE ────────────────────────────────────────────
function forge_ai_page() {
    $token = get_option('forge_ai_token', '');
    $anthropic_key = get_option('forge_ai_anthropic_key', '');
    $alerts = get_option('forge_ai_alerts', '1');
    $connected = !empty($token);
    ?>
    <div class="wrap">
      <style>
        .forge-wrap{background:#0c0c0d;border-radius:12px;padding:24px;max-width:620px;margin-top:20px}
        .forge-header{display:flex;align-items:center;gap:12px;margin-bottom:20px;padding-bottom:16px;border-bottom:1px solid rgba(255,255,255,.08)}
        .forge-icon{width:36px;height:36px;background:#ff6b35;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:800;color:#fff;flex-shrink:0}
        .forge-title{color:#f0f0f2;font-size:1.1rem;font-weight:700;margin:0}
        .forge-sub{color:#9090a0;font-size:.8rem;margin:2px 0 0}
        .forge-status{display:inline-flex;align-items:center;gap:6px;font-size:.75rem;padding:3px 10px;border-radius:100px;margin-left:auto}
        .status-on{background:rgba(34,201,122,.1);color:#22c97a}
        .status-off{background:rgba(107,107,120,.1);color:#9090a0}
        .forge-field{margin-bottom:16px}
        .forge-field label{display:block;color:#9090a0;font-size:.72rem;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px}
        .forge-field input[type=text],
        .forge-field input[type=password]{width:100%;background:#1a1a1d;border:1px solid rgba(255,255,255,.1);border-radius:6px;padding:9px 12px;color:#f0f0f2;font-size:.85rem;font-family:monospace}
        .forge-field input:focus{border-color:#ff6b35;outline:none}
        .forge-btn{background:#ff6b35;color:#fff;border:none;padding:10px 20px;border-radius:6px;font-size:.85rem;font-weight:700;cursor:pointer}
        .forge-feature{display:flex;align-items:flex-start;gap:10px;padding:10px;background:#1a1a1d;border-radius:8px;margin-bottom:8px}
        .forge-check{color:#22c97a;font-size:1rem;margin-top:1px}
        .forge-feature-text{color:#f0f0f2;font-size:.82rem;font-weight:600}
        .forge-feature-sub{color:#9090a0;font-size:.72rem;margin-top:2px}
        .forge-section-title{color:#9090a0;font-size:.7rem;text-transform:uppercase;letter-spacing:.08em;margin:20px 0 10px;padding-top:16px;border-top:1px solid rgba(255,255,255,.08)}
      </style>
      <div class="forge-wrap">
        <div class="forge-header">
          <div class="forge-icon">F</div>
          <div>
            <div class="forge-title">Forge AI — Website Intelligence</div>
            <div class="forge-sub">A product of Werdel Global Systems</div>
          </div>
          <span class="forge-status <?php echo $connected ? 'status-on' : 'status-off'; ?>">
            <?php echo $connected ? '● Connected' : '○ Not connected'; ?>
          </span>
        </div>

        <form method="post" action="options.php">
          <?php settings_fields('forge_ai'); ?>
          
          <div class="forge-field">
            <label>Forge AI Token</label>
            <input type="text" name="forge_ai_token" value="<?php echo esc_attr($token); ?>" placeholder="fat_xxxxxxxxxxxxxxxx_...">
            <p style="color:#6b6b78;font-size:.72rem;margin:4px 0 0">Find your token in your Forge AI dashboard</p>
          </div>

          <div class="forge-field">
            <label>Anthropic API Key <span style="color:#ff6b35">(required for AI auto-fix)</span></label>
            <input type="password" name="forge_ai_anthropic_key" value="<?php echo esc_attr($anthropic_key); ?>" placeholder="sk-ant-...">
            <p style="color:#6b6b78;font-size:.72rem;margin:4px 0 0">Get your key from console.anthropic.com</p>
          </div>

          <div class="forge-field" style="margin-top:12px">
            <label style="display:flex;align-items:center;gap:8px;cursor:pointer">
              <input type="checkbox" name="forge_ai_alerts" value="1" <?php checked($alerts, '1'); ?> style="width:auto">
              <span style="color:#f0f0f2;font-size:.85rem">Enable real-time building alerts</span>
            </label>
          </div>

          <?php submit_button('Save & Connect', 'primary', 'submit', false, ['class' => 'forge-btn', 'style' => 'margin-top:8px']); ?>
        </form>

        <?php if ($connected): ?>
        <div class="forge-section-title">Active Features</div>
        <div class="forge-feature"><span class="forge-check">✓</span><div><div class="forge-feature-text">Real-time building alerts</div><div class="forge-feature-sub">Popup alerts while viewing pages — with Fix Now buttons</div></div></div>
        <div class="forge-feature"><span class="forge-check">✓</span><div><div class="forge-feature-text">AI Auto-fix</div><div class="forge-feature-sub">Click "Fix Now" on any issue to apply an AI-generated fix instantly</div></div></div>
        <div class="forge-feature"><span class="forge-check">✓</span><div><div class="forge-feature-text">Meta description monitoring</div><div class="forge-feature-sub">Detects missing or weak meta descriptions</div></div></div>
        <div class="forge-feature"><span class="forge-check">✓</span><div><div class="forge-feature-text">Daily automated scans</div><div class="forge-feature-sub">Full 5-module scan sent to your Forge AI dashboard</div></div></div>
        <?php endif; ?>
      </div>
    </div>
    <?php
}

// ── INJECT MONITORING + FIX SCRIPT ───────────────────────
add_action('wp_footer', function() {
    $token = get_option('forge_ai_token', '');
    $alerts = get_option('forge_ai_alerts', '1');
    $has_fix = !empty(get_option('forge_ai_anthropic_key', ''));
    if (empty($token) || $alerts !== '1') return;
    
    $post_id = get_the_ID();
    $ajax_url = admin_url('admin-ajax.php');
    $nonce = wp_create_nonce('forge_ai_nonce');
    ?>
    <script>
    (function() {
      var token = '<?php echo esc_js($token); ?>';
      var hasFix = <?php echo $has_fix ? 'true' : 'false'; ?>;
      var postId = <?php echo intval($post_id); ?>;
      var ajaxUrl = '<?php echo esc_js($ajax_url); ?>';
      var nonce = '<?php echo esc_js($nonce); ?>';
      var endpoint = 'https://forge-ai-six-psi.vercel.app/api/realtime-check';
      var shownIssues = {};  // Track which issues are already showing

      function runChecks() {
        var issues = [];

        var meta = document.querySelector('meta[name="description"]');
        if (!meta || !meta.content || meta.content.trim().length < 10) {
          issues.push({type:'meta_description', name:'Missing meta description', description:'No meta description found on this page.', severity:'critical', fix:'Click Fix Now to generate an optimized meta description.'});
        }

        var h1s = document.querySelectorAll('h1');
        if (h1s.length === 0) {
          issues.push({type:'heading', name:'No H1 heading', description:'Pages should have exactly one H1 heading.', severity:'critical', fix:'Add a single H1 heading to this page.'});
        } else if (h1s.length > 1) {
          issues.push({type:'heading', name:'Multiple H1 tags (' + h1s.length + ')', description:'Pages should have exactly one H1 heading.', severity:'high', fix:'Remove extra H1 tags and keep only one.'});
        }

        var imgs = document.querySelectorAll('img');
        [].forEach.call(imgs, function(img) {
          // Skip tiny UI images, avatars, icons (under 50px or from wp-includes/wp-admin)
          var src = img.src || '';
          var isUI = src.indexOf('wp-includes') > -1 || src.indexOf('wp-admin') > -1 || 
                     src.indexOf('avatar') > -1 || src.indexOf('gravatar') > -1 ||
                     (img.width > 0 && img.width < 50) || (img.height > 0 && img.height < 50);
          if (isUI) return;
          if (!img.getAttribute('alt') || img.getAttribute('alt').trim() === '') {
            issues.push({type:'alt_text', name:'Image missing alt text', description:'This image is missing alt text.', severity:'high', fix:'Click Fix Now to generate descriptive alt text.', imageSrc: img.src});
          }
        });

        if (!document.title || document.title.trim().length < 5) {
          issues.push({type:'page_title', name:'Missing page title', description:'No title tag found on this page.', severity:'critical', fix:'A descriptive page title is required.'});
        } else if (document.title.length > 60) {
          issues.push({type:'page_title', name:'Page title too long (' + document.title.length + ' chars)', description:'Search engines truncate titles over 60 characters.', severity:'medium', fix:'Click Fix Now to shorten the title to under 60 characters.'});
        }

        return issues;
      }

      function applyFix(issue, btn, extraContext) {
        btn.textContent = 'Fixing...';
        btn.disabled = true;

        var data = new FormData();
        data.append('action', 'forge_ai_fix');
        data.append('nonce', nonce);
        data.append('issue_type', issue.type);
        data.append('post_id', postId);
        data.append('context', extraContext || document.title);
        if (issue.imageSrc) data.append('image_src', issue.imageSrc);

        fetch(ajaxUrl, {method:'POST', body:data})
          .then(function(r){ return r.json(); })
          .then(function(res) {
            if (res.success) {
              btn.textContent = '✓ Fixed!';
              btn.style.background = '#22c97a';
              btn.style.cursor = 'default';
              var applied = res.data.fix_text || '';
              if (applied) {
                var msg = document.createElement('div');
                msg.style.cssText = 'font-size:11px;color:#22c97a;margin-top:6px;line-height:1.4;font-style:italic';
                msg.textContent = '"' + applied.substring(0, 100) + (applied.length > 100 ? '...' : '') + '"';
                btn.parentElement.appendChild(msg);
              }
            } else {
              btn.textContent = 'Fix Now';
              btn.disabled = false;
              // Show context input if AI needs more info
              showContextInput(issue, btn);
            }
          })
          .catch(function() {
            btn.textContent = 'Fix Now';
            btn.disabled = false;
          });
      }

      function showContextInput(issue, btn) {
        var existing = btn.closest('.forge-context-area') ? btn.parentElement.querySelector('.forge-context-input') : btn.parentElement.querySelector('.forge-context-input');
        if (existing) return;

        var label = issue.type === 'alt_text' 
          ? 'Describe this image briefly:'
          : issue.type === 'meta_description'
          ? 'Briefly describe what this page is about:'
          : 'Add more context to generate a fix:';

        var wrapper = document.createElement('div');
        wrapper.className = 'forge-context-input';
        wrapper.style.cssText = 'margin-top:8px';
        wrapper.innerHTML = 
          '<div style="font-size:11px;color:#9090a0;margin-bottom:5px">' + label + '</div>' +
          '<textarea placeholder="e.g. A photo of our team at the company office..." style="width:100%;background:#0c0c0d;border:1px solid rgba(255,107,53,.3);border-radius:6px;padding:8px;color:#f0f0f2;font-size:12px;resize:vertical;min-height:60px;font-family:inherit"></textarea>' +
          '<button style="margin-top:6px;background:#ff6b35;color:#fff;border:none;padding:7px 14px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer;width:100%">Generate & Apply →</button>';

        btn.parentElement.appendChild(wrapper);

        wrapper.querySelector('button').addEventListener('click', function() {
          var ctx = wrapper.querySelector('textarea').value.trim();
          if (!ctx) { wrapper.querySelector('textarea').style.borderColor = '#ff3b3b'; return; }
          wrapper.remove();
          btn.textContent = 'Fix Now';
          btn.disabled = false;
          applyFix(issue, btn, ctx);
        });
      }

      // ── TOAST CONTAINER ──────────────────────────────────
      function getContainer() {
        var c = document.getElementById('forge-toast-container');
        if (!c) {
          c = document.createElement('div');
          c.id = 'forge-toast-container';
          c.style.cssText = 'position:fixed;bottom:20px;right:20px;z-index:999999;display:flex;flex-direction:column-reverse;gap:10px;width:320px;font-family:-apple-system,BlinkMacSystemFont,sans-serif';
          document.body.appendChild(c);
        }
        return c;
      }

      function showToast(issue) {
        var key = issue.type + (issue.imageSrc || '') + issue.name;
        if (shownIssues[key]) return;
        shownIssues[key] = true;

        var color = issue.severity==='critical'?'#ff6b6b':issue.severity==='high'?'#f5a623':'#4d9fff';
        var borderColor = issue.severity==='critical'?'rgba(255,59,59,.5)':issue.severity==='high'?'rgba(245,166,35,.5)':'rgba(77,159,255,.4)';
        var canFix = hasFix && postId && (issue.type==='meta_description'||issue.type==='alt_text'||issue.type==='page_title');

        var toast = document.createElement('div');
        toast.style.cssText = 'background:#131315;border:1px solid '+borderColor+';border-left:3px solid '+color+';border-radius:10px;padding:12px 14px;box-shadow:0 4px 20px rgba(0,0,0,.6);transform:translateX(120%);transition:transform .35s cubic-bezier(.34,1.56,.64,1);position:relative';

        toast.innerHTML =
          '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">' +
            '<div style="display:flex;align-items:center;gap:6px">' +
              '<div style="width:18px;height:18px;background:#ff6b35;border-radius:4px;display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:800;color:#fff">F</div>' +
              '<span style="font-size:10px;font-weight:700;color:'+color+'">'+issue.severity.toUpperCase()+'</span>' +
            '</div>' +
            '<button class="forge-dismiss" style="background:transparent;border:none;color:#6b6b78;cursor:pointer;font-size:15px;line-height:1;padding:0">✕</button>' +
          '</div>' +
          '<div style="color:#f0f0f2;font-size:13px;font-weight:600;margin-bottom:3px">'+issue.name+'</div>' +
          '<div style="color:#9090a0;font-size:11px;line-height:1.5;margin-bottom:'+(canFix?'8':'0')+'px">'+issue.description+'</div>' +
          (canFix ? '<button class="forge-fix-btn" style="background:#ff6b35;color:#fff;border:none;padding:6px 0;border-radius:6px;font-size:11px;font-weight:700;cursor:pointer;width:100%">Fix Now →</button>' : '') +
          '<div class="forge-context-area"></div>';

        var container = getContainer();
        container.appendChild(toast);
        setTimeout(function() { toast.style.transform = 'translateX(0)'; }, 50);

        toast.querySelector('.forge-dismiss').addEventListener('click', function() {
          dismissToast(toast, key);
        });

        var fixBtn = toast.querySelector('.forge-fix-btn');
        if (fixBtn) {
          fixBtn.addEventListener('click', function() {
            applyFix(issue, fixBtn, null);
          });
        }

        setTimeout(function() { dismissToast(toast, key); }, 12000);
      }

      function dismissToast(toast, key) {
        toast.style.transform = 'translateX(120%)';
        setTimeout(function() {
          if (toast.parentElement) toast.parentElement.removeChild(toast);
          delete shownIssues[key];
        }, 350);
      }

      // ── REAL-TIME DETECTION ───────────────────────────────
      function checkIssues() {
        var issues = runChecks();
        issues.forEach(function(issue) { showToast(issue); });
        if (issues.length > 0) {
          fetch(endpoint, {
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body:JSON.stringify({token:token,url:window.location.href,pageTitle:document.title,issues:issues,timestamp:new Date().toISOString()})
          }).catch(function(){});
        }
      }

      window.addEventListener('load', function() {
        setTimeout(checkIssues, 1000);
        setInterval(checkIssues, 5000);
      });

    })();
    </script>
    <?php
});

// ── META DESCRIPTION OUTPUT ───────────────────────────────
add_action('wp_head', function() {
    if (is_singular()) {
        $post_id = get_the_ID();
        $meta = get_post_meta($post_id, '_forge_meta_description', true);
        if ($meta && !defined('WPSEO_VERSION')) {
            echo '<meta name="description" content="' . esc_attr($meta) . '">' . "\n";
        }
    }
});

// ── PAGE SAVE HOOK ────────────────────────────────────────
add_action('save_post', function($post_id, $post, $update) {
    $token = get_option('forge_ai_token', '');
    if (empty($token) || wp_is_post_revision($post_id) || $post->post_status !== 'publish') return;

    $issues = [];
    $content = $post->post_content;

    $meta_desc = get_post_meta($post_id, '_yoast_wpseo_metadesc', true) ?: get_post_meta($post_id, '_forge_meta_description', true);
    if (empty($meta_desc)) {
        $issues[] = ['name'=>'Missing meta description','severity'=>'critical','fix'=>'Add a meta description.'];
    }

    preg_match_all('/<img[^>]+>/i', $content, $img_matches);
    $no_alt = 0;
    foreach ($img_matches[0] as $img) {
        if (!preg_match('/alt=["\'][^"\']+["\']/i', $img)) $no_alt++;
    }
    if ($no_alt > 0) {
        $issues[] = ['name'=>$no_alt.' image(s) missing alt text','severity'=>$no_alt>2?'critical':'high','fix'=>'Add alt text to every image.'];
    }

    if (empty($issues)) return;

    wp_remote_post('https://forge-ai-six-psi.vercel.app/api/realtime-check', [
        'body' => json_encode(['token'=>$token,'url'=>get_permalink($post_id),'pageTitle'=>$post->post_title,'issues'=>$issues,'timestamp'=>date('c')]),
        'headers' => ['Content-Type'=>'application/json'],
        'timeout' => 5,
        'blocking' => false
    ]);
}, 10, 3);
