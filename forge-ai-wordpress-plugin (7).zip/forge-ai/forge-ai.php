<?php
/**
 * Plugin Name: Forge AI — Website Intelligence
 * Plugin URI: https://forge-ai-six-psi.vercel.app
 * Description: Real-time building alerts, AI auto-fix, and continuous monitoring. A product of Werdel Global Systems.
 * Version: 1.2.0
 * Author: Werdel Global Systems
 */

if (!defined('ABSPATH')) exit;

// ── ACTIVATION ────────────────────────────────────────────
register_activation_hook(__FILE__, function() {
    add_option('forge_ai_token', '');
    add_option('forge_ai_anthropic_key', '');
    add_option('forge_ai_alerts', '1');
    add_option('forge_ai_auto_fix', '1');
});

// ── SETTINGS ──────────────────────────────────────────────
add_action('admin_init', function() {
    register_setting('forge_ai', 'forge_ai_token');
    register_setting('forge_ai', 'forge_ai_anthropic_key');
    register_setting('forge_ai', 'forge_ai_alerts');
    register_setting('forge_ai', 'forge_ai_auto_fix');
});

// ── ADMIN MENU ────────────────────────────────────────────
add_action('admin_menu', function() {
    add_menu_page('Forge AI', 'Forge AI', 'manage_options', 'forge-ai', 'forge_ai_page', 'dashicons-visibility', 30);
});

// ── AJAX: GENERATE AND APPLY FIX ─────────────────────────
add_action('wp_ajax_forge_ai_fix', 'forge_ai_apply_fix');
function forge_ai_apply_fix() {
    check_ajax_referer('forge_ai_nonce', 'nonce');
    
    $issue_type = sanitize_text_field($_POST['issue_type'] ?? '');
    $post_id = intval($_POST['post_id'] ?? 0);
    $context = sanitize_textarea_field($_POST['context'] ?? '');
    $anthropic_key = get_option('forge_ai_anthropic_key', '');

    if (empty($anthropic_key)) {
        wp_send_json_error(['message' => 'Please add your Anthropic API key in Forge AI settings.']);
        return;
    }

    if (!$post_id || !current_user_can('edit_post', $post_id)) {
        wp_send_json_error(['message' => 'Permission denied.']);
        return;
    }

    $post = get_post($post_id);
    $page_content = wp_strip_all_tags($post->post_content);
    $page_title = $post->post_title;
    $page_url = get_permalink($post_id);

    // Build prompt based on issue type
    $prompt = '';
    $fix_applied = '';

    if ($issue_type === 'meta_description') {
        $prompt = "Write a meta description for this webpage. Return ONLY the meta description text, nothing else. It must be between 120-160 characters, describe the page accurately, and include a call to action.\n\nPage Title: {$page_title}\nPage URL: {$page_url}\nPage Content: " . substr($page_content, 0, 1500);
    } elseif ($issue_type === 'page_title') {
        $prompt = "Rewrite this page title to be under 60 characters. Keep the meaning and include the most important keywords. Return ONLY the new title, nothing else.\n\nCurrent title: {$page_title}\nPage content: " . substr($page_content, 0, 500);
    } elseif ($issue_type === 'alt_text') {
        $image_src = sanitize_text_field($_POST['image_src'] ?? '');
        $prompt = "Write alt text for an image on this webpage. Return ONLY the alt text, nothing else. Keep it under 125 characters and describe what the image likely shows based on context.\n\nImage URL: {$image_src}\nPage Title: {$page_title}\nPage Context: " . substr($page_content, 0, 500);
    } else {
        wp_send_json_error(['message' => 'Unknown issue type.']);
        return;
    }

    // Call Anthropic API
    $response = wp_remote_post('https://api.anthropic.com/v1/messages', [
        'headers' => [
            'Content-Type' => 'application/json',
            'x-api-key' => $anthropic_key,
            'anthropic-version' => '2023-06-01'
        ],
        'body' => json_encode([
            'model' => 'claude-haiku-4-5-20251001',
            'max_tokens' => 300,
            'messages' => [['role' => 'user', 'content' => $prompt]]
        ]),
        'timeout' => 30
    ]);

    if (is_wp_error($response)) {
        wp_send_json_error(['message' => 'API error: ' . $response->get_error_message()]);
        return;
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);
    $fix_text = trim($body['content'][0]['text'] ?? '');

    if (empty($fix_text)) {
        wp_send_json_error(['message' => 'Could not generate fix. Please try again.']);
        return;
    }

    // Apply the fix
    if ($issue_type === 'meta_description') {
        // Save to Yoast if available, otherwise to post meta
        if (defined('WPSEO_VERSION')) {
            update_post_meta($post_id, '_yoast_wpseo_metadesc', $fix_text);
        } else {
            update_post_meta($post_id, '_forge_ai_meta_desc', $fix_text);
            // Also inject via wp_head if Yoast not available
            update_post_meta($post_id, '_forge_meta_description', $fix_text);
        }
        $fix_applied = 'Meta description set to: "' . $fix_text . '"';
    } elseif ($issue_type === 'page_title') {
        wp_update_post(['ID' => $post_id, 'post_title' => $fix_text]);
        $fix_applied = 'Page title updated to: "' . $fix_text . '"';
    } elseif ($issue_type === 'alt_text') {
        $image_src = sanitize_text_field($_POST['image_src'] ?? '');
        // Find attachment by URL and update alt text
        $attachment_id = attachment_url_to_postid($image_src);
        if ($attachment_id) {
            update_post_meta($attachment_id, '_wp_attachment_image_alt', $fix_text);
        }
        $fix_applied = 'Alt text set to: "' . $fix_text . '"';
    }

    wp_send_json_success([
        'message' => '✓ Fixed! ' . $fix_applied,
        'fix_text' => $fix_text
    ]);
}

// ── ADMIN PAGE ────────────────────────────────────────────
function forge_ai_page() {
    $token = get_option('forge_ai_token', '');
    $anthropic_key = get_option('forge_ai_anthropic_key', '');
    $alerts = get_option('forge_ai_alerts', '1');
    $connected = !empty($token);
    ?>
    <div class="wrap">
      <style>
        .forge-wrap{background:#0c0c0d;border-radius:12px;padding:24px;max-width:620px;margin-top:20px}
        .forge-header{display:flex;align-items:center;gap:12px;margin-bottom:20px;padding-bottom:16px;border-bottom:1px solid rgba(255,255,255,.08)}
        .forge-icon{width:36px;height:36px;background:#ff6b35;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:800;color:#fff;flex-shrink:0}
        .forge-title{color:#f0f0f2;font-size:1.1rem;font-weight:700;margin:0}
        .forge-sub{color:#9090a0;font-size:.8rem;margin:2px 0 0}
        .forge-status{display:inline-flex;align-items:center;gap:6px;font-size:.75rem;padding:3px 10px;border-radius:100px;margin-left:auto}
        .status-on{background:rgba(34,201,122,.1);color:#22c97a}
        .status-off{background:rgba(107,107,120,.1);color:#9090a0}
        .forge-field{margin-bottom:16px}
        .forge-field label{display:block;color:#9090a0;font-size:.72rem;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px}
        .forge-field input[type=text],
        .forge-field input[type=password]{width:100%;background:#1a1a1d;border:1px solid rgba(255,255,255,.1);border-radius:6px;padding:9px 12px;color:#f0f0f2;font-size:.85rem;font-family:monospace}
        .forge-field input:focus{border-color:#ff6b35;outline:none}
        .forge-btn{background:#ff6b35;color:#fff;border:none;padding:10px 20px;border-radius:6px;font-size:.85rem;font-weight:700;cursor:pointer}
        .forge-feature{display:flex;align-items:flex-start;gap:10px;padding:10px;background:#1a1a1d;border-radius:8px;margin-bottom:8px}
        .forge-check{color:#22c97a;font-size:1rem;margin-top:1px}
        .forge-feature-text{color:#f0f0f2;font-size:.82rem;font-weight:600}
        .forge-feature-sub{color:#9090a0;font-size:.72rem;margin-top:2px}
        .forge-section-title{color:#9090a0;font-size:.7rem;text-transform:uppercase;letter-spacing:.08em;margin:20px 0 10px;padding-top:16px;border-top:1px solid rgba(255,255,255,.08)}
      </style>
      <div class="forge-wrap">
        <div class="forge-header">
          <div class="forge-icon">F</div>
          <div>
            <div class="forge-title">Forge AI — Website Intelligence</div>
            <div class="forge-sub">A product of Werdel Global Systems</div>
          </div>
          <span class="forge-status <?php echo $connected ? 'status-on' : 'status-off'; ?>">
            <?php echo $connected ? '● Connected' : '○ Not connected'; ?>
          </span>
        </div>

        <form method="post" action="options.php">
          <?php settings_fields('forge_ai'); ?>
          
          <div class="forge-field">
            <label>Forge AI Token</label>
            <input type="text" name="forge_ai_token" value="<?php echo esc_attr($token); ?>" placeholder="fat_xxxxxxxxxxxxxxxx_...">
            <p style="color:#6b6b78;font-size:.72rem;margin:4px 0 0">Find your token in your Forge AI dashboard</p>
          </div>

          <div class="forge-field">
            <label>Anthropic API Key <span style="color:#ff6b35">(required for AI auto-fix)</span></label>
            <input type="password" name="forge_ai_anthropic_key" value="<?php echo esc_attr($anthropic_key); ?>" placeholder="sk-ant-...">
            <p style="color:#6b6b78;font-size:.72rem;margin:4px 0 0">Get your key from console.anthropic.com</p>
          </div>

          <div class="forge-field" style="margin-top:12px">
            <label style="display:flex;align-items:center;gap:8px;cursor:pointer">
              <input type="checkbox" name="forge_ai_alerts" value="1" <?php checked($alerts, '1'); ?> style="width:auto">
              <span style="color:#f0f0f2;font-size:.85rem">Enable real-time building alerts</span>
            </label>
          </div>

          <?php submit_button('Save & Connect', 'primary', 'submit', false, ['class' => 'forge-btn', 'style' => 'margin-top:8px']); ?>
        </form>

        <?php if ($connected): ?>
        <div class="forge-section-title">Active Features</div>
        <div class="forge-feature"><span class="forge-check">✓</span><div><div class="forge-feature-text">Real-time building alerts</div><div class="forge-feature-sub">Popup alerts while viewing pages — with Fix Now buttons</div></div></div>
        <div class="forge-feature"><span class="forge-check">✓</span><div><div class="forge-feature-text">AI Auto-fix</div><div class="forge-feature-sub">Click "Fix Now" on any issue to apply an AI-generated fix instantly</div></div></div>
        <div class="forge-feature"><span class="forge-check">✓</span><div><div class="forge-feature-text">Meta description monitoring</div><div class="forge-feature-sub">Detects missing or weak meta descriptions</div></div></div>
        <div class="forge-feature"><span class="forge-check">✓</span><div><div class="forge-feature-text">Daily automated scans</div><div class="forge-feature-sub">Full 5-module scan sent to your Forge AI dashboard</div></div></div>
        <?php endif; ?>
      </div>
    </div>
    <?php
}

// ── INJECT MONITORING + FIX SCRIPT ───────────────────────
add_action('wp_footer', function() {
    $token = get_option('forge_ai_token', '');
    $alerts = get_option('forge_ai_alerts', '1');
    $has_fix = !empty(get_option('forge_ai_anthropic_key', ''));
    if (empty($token) || $alerts !== '1') return;
    
    $post_id = get_the_ID();
    $ajax_url = admin_url('admin-ajax.php');
    $nonce = wp_create_nonce('forge_ai_nonce');
    ?>
    <script>
    (function() {
      var token = '<?php echo esc_js($token); ?>';
      var hasFix = <?php echo $has_fix ? 'true' : 'false'; ?>;
      var postId = <?php echo intval($post_id); ?>;
      var ajaxUrl = '<?php echo esc_js($ajax_url); ?>';
      var nonce = '<?php echo esc_js($nonce); ?>';
      var endpoint = 'https://forge-ai-six-psi.vercel.app/api/realtime-check';

      function runChecks() {
        var issues = [];

        var meta = document.querySelector('meta[name="description"]');
        if (!meta || !meta.content || meta.content.trim().length < 10) {
          issues.push({type:'meta_description', name:'Missing meta description', description:'This page has no meta description.', severity:'critical', fix:'AI will write a 120-160 character meta description based on your page content.'});
        }

        var h1s = document.querySelectorAll('h1');
        if (h1s.length === 0) {
          issues.push({type:'heading', name:'No H1 heading', description:'Every page needs exactly one H1.', severity:'critical', fix:'Add an H1 heading to this page.'});
        } else if (h1s.length > 1) {
          issues.push({type:'heading', name:'Multiple H1 tags (' + h1s.length + ')', description:'Pages should have exactly one H1.', severity:'high', fix:'Remove extra H1 tags — keep only one.'});
        }

        var imgs = document.querySelectorAll('img');
        [].forEach.call(imgs, function(img) {
          if (!img.getAttribute('alt') || img.getAttribute('alt').trim() === '') {
            issues.push({type:'alt_text', name:'Image missing alt text', description:'This image has no alt text.', severity:'high', fix:'AI will write descriptive alt text for this image.', imageSrc: img.src});
          }
        });

        if (!document.title || document.title.trim().length < 5) {
          issues.push({type:'page_title', name:'Missing page title', description:'This page has no title tag.', severity:'critical', fix:'Add a descriptive page title.'});
        } else if (document.title.length > 60) {
          issues.push({type:'page_title', name:'Page title too long (' + document.title.length + ' chars)', description:'Google truncates titles over 60 characters.', severity:'medium', fix:'AI will rewrite your title to under 60 characters.'});
        }

        return issues;
      }

      function applyFix(issue, btn) {
        btn.textContent = 'Fixing...';
        btn.disabled = true;

        var data = new FormData();
        data.append('action', 'forge_ai_fix');
        data.append('nonce', nonce);
        data.append('issue_type', issue.type);
        data.append('post_id', postId);
        data.append('context', document.title);
        if (issue.imageSrc) data.append('image_src', issue.imageSrc);

        fetch(ajaxUrl, {method:'POST', body:data})
          .then(function(r){ return r.json(); })
          .then(function(res) {
            if (res.success) {
              btn.textContent = '✓ Fixed!';
              btn.style.background = '#22c97a';
              btn.parentElement.style.opacity = '.6';
              // Show success message
              var msg = document.createElement('div');
              msg.style.cssText = 'font-size:11px;color:#22c97a;margin-top:6px;line-height:1.4';
              msg.textContent = res.data.message;
              btn.parentElement.appendChild(msg);
            } else {
              btn.textContent = 'Fix Now';
              btn.disabled = false;
              alert('Error: ' + (res.data.message || 'Could not apply fix'));
            }
          })
          .catch(function() {
            btn.textContent = 'Fix Now';
            btn.disabled = false;
          });
      }

      function showPopup(issues) {
        ['forge-ai-popup','forge-ai-overlay'].forEach(function(id){ var el=document.getElementById(id); if(el) el.remove(); });
        if (issues.length === 0) return;

        var critical = issues.filter(function(i){ return i.severity==='critical'; }).length;

        var overlay = document.createElement('div');
        overlay.id = 'forge-ai-overlay';
        overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:999998;backdrop-filter:blur(3px)';

        var popup = document.createElement('div');
        popup.id = 'forge-ai-popup';
        popup.style.cssText = 'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);z-index:999999;width:500px;max-width:92vw;max-height:85vh;overflow-y:auto;background:#131315;border:1px solid rgba(255,107,53,.4);border-radius:16px;padding:24px;box-shadow:0 24px 60px rgba(0,0,0,.8);font-family:-apple-system,BlinkMacSystemFont,sans-serif';

        var issuesHtml = issues.map(function(i) {
          var color = i.severity==='critical'?'#ff6b6b':i.severity==='high'?'#f5a623':'#4d9fff';
          var bg = i.severity==='critical'?'rgba(255,59,59,.12)':i.severity==='high'?'rgba(245,166,35,.12)':'rgba(77,159,255,.1)';
          var canFix = hasFix && postId && (i.type==='meta_description'||i.type==='alt_text'||i.type==='page_title');
          var fixBtn = canFix ? '<button class="forge-fix-btn" data-type="'+i.type+'" data-img="'+(i.imageSrc||'')+'" style="background:#ff6b35;color:#fff;border:none;padding:5px 12px;border-radius:5px;font-size:11px;font-weight:700;cursor:pointer;margin-top:8px">Fix Now →</button>' : '';
          return '<div style="background:#1a1a1d;border-radius:8px;padding:12px;margin-bottom:10px;border-left:3px solid '+color+'">' +
            '<div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">' +
            '<span style="font-size:10px;font-weight:700;padding:1px 7px;border-radius:3px;background:'+bg+';color:'+color+'">'+i.severity.toUpperCase()+'</span>' +
            '<span style="color:#f0f0f2;font-size:13px;font-weight:600">'+i.name+'</span>' +
            '</div>' +
            '<div style="color:#9090a0;font-size:12px;line-height:1.5;margin-bottom:4px">'+i.description+'</div>' +
            '<div style="color:#6b6b78;font-size:11px;font-style:italic">'+i.fix+'</div>' +
            fixBtn +
            '</div>';
        }).join('');

        popup.innerHTML = 
          '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">' +
            '<div style="display:flex;align-items:center;gap:10px">' +
              '<div style="width:30px;height:30px;background:#ff6b35;border-radius:7px;display:flex;align-items:center;justify-content:center;font-weight:800;color:#fff;font-size:14px">F</div>' +
              '<div><div style="color:#f0f0f2;font-weight:700;font-size:15px">Forge AI</div><div style="color:#9090a0;font-size:11px">'+issues.length+' issue'+(issues.length>1?'s':'')+' found on this page</div></div>' +
            '</div>' +
            '<button onclick="document.getElementById(\'forge-ai-popup\').remove();document.getElementById(\'forge-ai-overlay\').remove();" style="background:transparent;border:none;color:#6b6b78;cursor:pointer;font-size:20px;line-height:1;padding:4px">✕</button>' +
          '</div>' +
          (critical > 0 ? '<div style="background:rgba(255,59,59,.08);border:1px solid rgba(255,59,59,.2);border-radius:8px;padding:10px 14px;margin-bottom:14px;font-size:12px;color:#ff8080">⚠ '+critical+' critical issue'+(critical>1?'s':'')+' — fix before publishing</div>' : '') +
          issuesHtml +
          '<div style="display:flex;justify-content:space-between;align-items:center;margin-top:14px;padding-top:12px;border-top:1px solid rgba(255,255,255,.06)">' +
            '<a href="https://forge-ai-six-psi.vercel.app/forge-ai-report.html" target="_blank" style="font-size:12px;color:#ff6b35;text-decoration:none">View full report →</a>' +
            '<button onclick="document.getElementById(\'forge-ai-popup\').remove();document.getElementById(\'forge-ai-overlay\').remove();" style="background:#1a1a1d;color:#f0f0f2;border:1px solid rgba(255,255,255,.1);padding:8px 18px;border-radius:7px;font-size:13px;cursor:pointer">Dismiss</button>' +
          '</div>';

        overlay.onclick = function() { popup.remove(); overlay.remove(); };
        document.body.appendChild(overlay);
        document.body.appendChild(popup);

        // Attach Fix Now button handlers
        popup.querySelectorAll('.forge-fix-btn').forEach(function(btn) {
          btn.addEventListener('click', function() {
            var type = btn.getAttribute('data-type');
            var imgSrc = btn.getAttribute('data-img');
            var issue = issues.find(function(i){ return i.type===type && (i.imageSrc||'')===(imgSrc||''); });
            if (issue) applyFix(issue, btn);
          });
        });

        // Send to Forge AI dashboard
        fetch(endpoint, {
          method:'POST',
          headers:{'Content-Type':'application/json'},
          body:JSON.stringify({token:token,url:window.location.href,pageTitle:document.title,issues:issues,timestamp:new Date().toISOString()})
        }).catch(function(){});
      }

      var alertShown = false;

      // Show on page load
      window.addEventListener('load', function() {
        setTimeout(function() {
          if (alertShown) return;
          var issues = runChecks();
          if (issues.length > 0) {
            alertShown = true;
            showPopup(issues);
          }
        }, 1500);
      });

      // Show when Save/Update/Publish clicked in WP editor
      document.addEventListener('click', function(e) {
        var t = e.target;
        if (!t) return;
        var id = t.id || '';
        var name = t.name || '';
        var text = (t.textContent || '').trim();
        var cls = t.className || '';
        var isSave = (id === 'publish' || id === 'save-post' || name === 'save' ||
          cls.indexOf('editor-post-publish-button') > -1 ||
          cls.indexOf('editor-post-save-draft') > -1 ||
          text === 'Update' || text === 'Publish' || text === 'Save Draft');
        if (isSave) {
          alertShown = false;
          setTimeout(function() {
            if (alertShown) return;
            var issues = runChecks();
            if (issues.length > 0) {
              alertShown = true;
              showPopup(issues);
            }
          }, 1800);
        }
      });

    })();
    </script>
    <?php
});

// ── META DESCRIPTION OUTPUT ───────────────────────────────
add_action('wp_head', function() {
    if (is_singular()) {
        $post_id = get_the_ID();
        $meta = get_post_meta($post_id, '_forge_meta_description', true);
        if ($meta && !defined('WPSEO_VERSION')) {
            echo '<meta name="description" content="' . esc_attr($meta) . '">' . "\n";
        }
    }
});

// ── PAGE SAVE HOOK ────────────────────────────────────────
add_action('save_post', function($post_id, $post, $update) {
    $token = get_option('forge_ai_token', '');
    if (empty($token) || wp_is_post_revision($post_id) || $post->post_status !== 'publish') return;

    $issues = [];
    $content = $post->post_content;

    $meta_desc = get_post_meta($post_id, '_yoast_wpseo_metadesc', true) ?: get_post_meta($post_id, '_forge_meta_description', true);
    if (empty($meta_desc)) {
        $issues[] = ['name'=>'Missing meta description','severity'=>'critical','fix'=>'Add a meta description.'];
    }

    preg_match_all('/<img[^>]+>/i', $content, $img_matches);
    $no_alt = 0;
    foreach ($img_matches[0] as $img) {
        if (!preg_match('/alt=["\'][^"\']+["\']/i', $img)) $no_alt++;
    }
    if ($no_alt > 0) {
        $issues[] = ['name'=>$no_alt.' image(s) missing alt text','severity'=>$no_alt>2?'critical':'high','fix'=>'Add alt text to every image.'];
    }

    if (empty($issues)) return;

    wp_remote_post('https://forge-ai-six-psi.vercel.app/api/realtime-check', [
        'body' => json_encode(['token'=>$token,'url'=>get_permalink($post_id),'pageTitle'=>$post->post_title,'issues'=>$issues,'timestamp'=>date('c')]),
        'headers' => ['Content-Type'=>'application/json'],
        'timeout' => 5,
        'blocking' => false
    ]);
}, 10, 3);
