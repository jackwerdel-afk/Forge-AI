(function() {
  var el = wp.element.createElement;
  var Fragment = wp.element.Fragment;
  var useState = wp.element.useState;
  var useEffect = wp.element.useEffect;
  var PanelBody = wp.components.PanelBody;
  var registerPlugin = wp.plugins.registerPlugin;
  var useSelect = wp.data.useSelect;

  // Use wp.editor for WP 6.6+ with fallback
  var editorPlugin = wp.editor || wp.editPost;
  var PluginSidebar = editorPlugin.PluginSidebar;
  var PluginSidebarMoreMenuItem = editorPlugin.PluginSidebarMoreMenuItem;

  var data = window.forgeAiData || {};

  function runChecks(content, title, metaDesc) {
    var issues = [];

    // Meta description check
    if (!metaDesc || metaDesc.trim().length < 10) {
      issues.push({ type:'meta_description', severity:'critical', name:'Missing meta description', desc:'No meta description set for this page.', fixable:true, imageSrc:'' });
    } else if (metaDesc.length > 160) {
      issues.push({ type:'meta_description', severity:'medium', name:'Meta description too long ('+metaDesc.length+' chars)', desc:'Keep meta descriptions under 160 characters.', fixable:true, imageSrc:'' });
    }

    // Title check
    if (!title || title.trim().length < 3) {
      issues.push({ type:'page_title', severity:'critical', name:'Missing page title', desc:'A descriptive title is required for SEO.', fixable:true, imageSrc:'' });
    } else if (title.length > 60) {
      issues.push({ type:'page_title', severity:'medium', name:'Page title too long ('+title.length+' chars)', desc:'Search engines truncate titles over 60 characters.', fixable:true, imageSrc:'' });
    }

    // H1 check
    var h1Count = (content.match(/<!-- wp:heading \{"level":1/gi) || []).length +
                  (content.match(/<h1[\s>]/gi) || []).length;
    if (h1Count === 0) {
      issues.push({ type:'heading', severity:'critical', name:'No H1 heading found', desc:'Pages should have exactly one H1 heading.', fixable:false, imageSrc:'' });
    } else if (h1Count > 1) {
      issues.push({ type:'heading', severity:'high', name:'Multiple H1 headings ('+h1Count+')', desc:'Remove extra H1 headings and keep only one.', fixable:false, imageSrc:'' });
    }

    // Image alt text check
    var imgTags = content.match(/<img[^>]+>/gi) || [];
    imgTags.forEach(function(img) {
      if (img.indexOf('wp-includes') > -1 || img.indexOf('gravatar') > -1) return;
      if (!img.match(/alt=["'][^"']+["']/i)) {
        var srcMatch = img.match(/src=["']([^"']+)["']/i);
        issues.push({ type:'alt_text', severity:'high', name:'Image missing alt text', desc:'This image has no alt text set.', fixable:true, imageSrc: srcMatch ? srcMatch[1] : '' });
      }
    });

    return issues;
  }

  function IssueCard(props) {
    var issue = props.issue;
    var postId = props.postId;
    var getTitle = props.getTitle;
    var getContent = props.getContent;
    var statusState = useState('idle');
    var currentStatus = statusState[0];
    var setCurrentStatus = statusState[1];
    var resultState = useState('');
    var resultText = resultState[0];
    var setResultText = resultState[1];
    var contextState = useState('');
    var contextVal = contextState[0];
    var setContextVal = contextState[1];

    function doFix(extraCtx) {
      setCurrentStatus('loading');

      var title = getTitle ? getTitle() : '';
      var content = getContent ? getContent() : '';
      var cleanContent = content.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim().substring(0, 1500);
      var apiKey = data.anthropicKey;

      if (!apiKey) {
        setCurrentStatus('idle');
        alert('Add your Anthropic API key in Forge AI settings to use auto-fix.');
        return;
      }

      var prompt = '';
      if (issue.type === 'meta_description') {
        var ctx = extraCtx || cleanContent || title || 'general webpage';
        prompt = 'Write a meta description. RULES: Return ONLY the meta description text, nothing else. 120-160 characters. Professional tone. NEVER use the word I. NEVER ask for more information. Always generate something.\n\nTitle: ' + title + '\nContext: ' + ctx;
      } else if (issue.type === 'page_title') {
        prompt = 'Rewrite this title to under 60 characters. RULES: Return ONLY the new title, nothing else. Professional. NEVER use I. Always generate something.\n\nTitle: ' + (title || 'Untitled');
      } else if (issue.type === 'alt_text') {
        var fn = (issue.imageSrc||'').split('/').pop().split('?')[0].split('.')[0].replace(/[-_]/g,' ')||'image';
        var ac = extraCtx || cleanContent.substring(0,300) || title || 'webpage';
        prompt = 'Write image alt text. RULES: Return ONLY the alt text, nothing else. Under 125 characters. NEVER use the word I. NEVER ask for more information. Always generate something specific.\n\nFilename: ' + fn + '\nPage: ' + title + '\nContext: ' + ac;
      }

      fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': apiKey,
          'anthropic-version': '2023-06-01',
          'anthropic-dangerous-direct-browser-access': 'true'
        },
        body: JSON.stringify({
          model: 'claude-haiku-4-5-20251001',
          max_tokens: 200,
          system: 'You are an SEO expert. Never use the word I or refer to yourself. Return only the requested content, nothing else.',
          messages: [{ role: 'user', content: prompt }]
        })
      })
      .then(function(r) { return r.json(); })
      .then(function(res) {
        if (res.error) {
          setCurrentStatus('idle');
          alert('API error: ' + res.error.message);
          return;
        }
        var fixText = (res.content && res.content[0] && res.content[0].text || '').trim();
        // If response asks for more info or uses "I", show context input
        var needsContext = !fixText || 
          fixText.toLowerCase().indexOf(' i ') > -1 ||
          fixText.toLowerCase().startsWith('i ') ||
          fixText.toLowerCase().indexOf('please provide') > -1 ||
          fixText.toLowerCase().indexOf('more information') > -1 ||
          fixText.toLowerCase().indexOf('need more') > -1 ||
          fixText.toLowerCase().indexOf("i need") > -1 ||
          fixText.toLowerCase().indexOf("i don't") > -1 ||
          fixText.toLowerCase().indexOf("i can't") > -1;
        if (needsContext) { setCurrentStatus('context'); return; }

        // Apply fix directly to Gutenberg editor
        if (issue.type === 'page_title') {
          wp.data.dispatch('core/editor').editPost({ title: fixText });
        } else if (issue.type === 'meta_description') {
          wp.data.dispatch('core/editor').editPost({
            meta: { _yoast_wpseo_metadesc: fixText, _forge_meta_description: fixText }
          });
        } else if (issue.type === 'alt_text') {
          // For alt text save via AJAX since it needs media library access
          var formData = new FormData();
          formData.append('action', 'forge_ai_fix');
          formData.append('nonce', data.nonce);
          formData.append('issue_type', 'alt_text');
          formData.append('post_id', postId);
          formData.append('image_src', issue.imageSrc || '');
          formData.append('fix_text_override', fixText);
          fetch(data.ajaxUrl, { method: 'POST', body: formData }).catch(function(){});
        }

        setCurrentStatus('success');
        setResultText(fixText);
      })
      .catch(function(err) {
        setCurrentStatus('idle');
        alert('Network error: ' + err.message);
      });
    }

    var borderColor = issue.severity === 'critical' ? '#ff3b3b' : issue.severity === 'high' ? '#f5a623' : '#4d9fff';
    var sevColor = issue.severity === 'critical' ? '#ff6b6b' : issue.severity === 'high' ? '#f5a623' : '#4d9fff';
    var sevBg = issue.severity === 'critical' ? 'rgba(255,59,59,.15)' : issue.severity === 'high' ? 'rgba(245,166,35,.15)' : 'rgba(77,159,255,.12)';

    return el('div', {
      style: {
        background: '#1a1a1d',
        borderRadius: '7px',
        padding: '10px',
        marginBottom: '8px',
        borderLeft: '3px solid ' + borderColor,
        fontFamily: '-apple-system, BlinkMacSystemFont, sans-serif'
      }
    },
      el('span', {
        style: { fontSize: '9px', fontWeight: '700', padding: '1px 6px', borderRadius: '3px', background: sevBg, color: sevColor, letterSpacing: '0.05em', display: 'inline-block', marginBottom: '5px' }
      }, issue.severity.toUpperCase()),
      el('div', { style: { color: '#f0f0f2', fontSize: '12px', fontWeight: '600', marginBottom: '3px' } }, issue.name),
      el('div', { style: { color: '#9090a0', fontSize: '11px', lineHeight: '1.4', marginBottom: issue.fixable ? '7px' : '0' } }, issue.desc),

      currentStatus === 'idle' && issue.fixable && data.hasFix &&
        el('button', {
          style: { background: '#ff6b35', color: '#fff', border: 'none', padding: '6px 0', borderRadius: '5px', fontSize: '11px', fontWeight: '700', cursor: 'pointer', width: '100%', display: 'block' },
          onClick: function() { doFix(''); }
        }, 'Fix Now →'),

      currentStatus === 'loading' &&
        el('button', {
          style: { background: '#ff6b35', color: '#fff', border: 'none', padding: '6px 0', borderRadius: '5px', fontSize: '11px', fontWeight: '700', width: '100%', opacity: '0.6' },
          disabled: true
        }, 'Fixing...'),

      currentStatus === 'success' &&
        el(Fragment, null,
          el('div', { style: { color: '#22c97a', fontSize: '11px', fontWeight: '600', marginTop: '2px' } }, '✓ Fixed!'),
          resultText && el('div', { style: { color: '#9090a0', fontSize: '10px', fontStyle: 'italic', marginTop: '2px' } },
            '"' + resultText.substring(0, 80) + (resultText.length > 80 ? '...' : '') + '"'
          )
        ),

      currentStatus === 'context' &&
        el('div', null,
          el('div', { style: { color: '#9090a0', fontSize: '10px', marginBottom: '4px', marginTop: '4px' } },
            issue.type === 'alt_text' ? 'Describe this image briefly:' :
            issue.type === 'meta_description' ? 'Briefly describe this page:' : 'Add context:'
          ),
          el('textarea', {
            value: contextVal,
            placeholder: issue.type === 'alt_text' ? 'e.g. Team photo at company HQ' : 'e.g. Contact page for a Denver web agency',
            onChange: function(e) { setContextVal(e.target.value); },
            style: { width: '100%', background: '#0c0c0d', border: '1px solid rgba(255,107,53,.3)', borderRadius: '5px', padding: '6px 8px', color: '#f0f0f2', fontSize: '11px', minHeight: '50px', fontFamily: 'inherit', resize: 'vertical', boxSizing: 'border-box' }
          }),
          el('button', {
            style: { background: '#ff6b35', color: '#fff', border: 'none', padding: '5px 0', borderRadius: '5px', fontSize: '11px', fontWeight: '700', cursor: 'pointer', width: '100%', marginTop: '5px' },
            onClick: function() { if (contextVal.trim()) doFix(contextVal); }
          }, 'Generate & Apply →')
        )
    );
  }

  function ForgeAiPanel() {
    var issuesState = useState([]);
    var issues = issuesState[0];
    var setIssues = issuesState[1];
    var checkingState = useState(true);
    var checking = checkingState[0];
    var setChecking = checkingState[1];

    var postContent = useSelect(function(select) {
      return select('core/editor').getEditedPostAttribute('content') || '';
    });
    var postTitle = useSelect(function(select) {
      return select('core/editor').getEditedPostAttribute('title') || '';
    });
    var postMeta = useSelect(function(select) {
      return select('core/editor').getEditedPostAttribute('meta') || {};
    });
    var postId = useSelect(function(select) {
      return select('core/editor').getCurrentPostId();
    });

    var metaDesc = postMeta._yoast_wpseo_metadesc || postMeta._forge_meta_description || '';

    useEffect(function() {
      setChecking(true);
      var timer = setTimeout(function() {
        var found = runChecks(postContent, postTitle, metaDesc);
        setIssues(found);
        setChecking(false);
      }, 600);
      return function() { clearTimeout(timer); };
    }, [postContent, postTitle, metaDesc]);

    return el('div', { style: { background: '#0c0c0d', minHeight: '100px' } },
      el('div', { style: { display: 'flex', alignItems: 'center', gap: '8px', padding: '10px 12px', background: '#131315', borderBottom: '1px solid rgba(255,255,255,0.08)', marginBottom: '0' } },
        el('div', { style: { width: '22px', height: '22px', background: '#ff6b35', borderRadius: '5px', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontSize: '11px', fontWeight: '800', color: '#fff', flexShrink: '0', lineHeight: '1' } }, 'F'),
        el('div', { style: { color: '#f0f0f2', fontSize: '12px', fontWeight: '700' } }, 'Forge AI — Live Analysis'),
        el('div', { style: { marginLeft: 'auto', fontSize: '10px', color: '#22c97a', display: 'flex', alignItems: 'center', gap: '4px' } },
          el('div', { style: { width: '6px', height: '6px', background: '#22c97a', borderRadius: '50%' } }),
          'Live'
        )
      ),
      el('div', { style: { padding: '10px' } },
        checking
          ? el('div', { style: { textAlign: 'center', padding: '16px', color: '#6b6b78', fontSize: '11px' } }, 'Analyzing...')
          : issues.length === 0
          ? el('div', { style: { textAlign: 'center', padding: '16px' } },
              el('div', { style: { fontSize: '20px', marginBottom: '6px' } }, '✓'),
              el('div', { style: { color: '#22c97a', fontSize: '12px', fontWeight: '600' } }, 'No issues found')
            )
          : el(Fragment, null,
              issues.map(function(issue, i) {
                return el(IssueCard, {
                  key: issue.type + i + (issue.imageSrc || ''),
                  issue: issue,
                  postId: postId,
                  getTitle: function() { return postTitle; },
                  getContent: function() { return postContent; }
                });
              })
            )
      )
    );
  }

  registerPlugin('forge-ai-sidebar', {
    render: function() {
      return el(Fragment, null,
        el(PluginSidebarMoreMenuItem, { target: 'forge-ai-sidebar' }, 'Forge AI'),
        el(PluginSidebar, {
          name: 'forge-ai-sidebar',
          title: 'Forge AI'
        },
          el(PanelBody, { initialOpen: true },
            el(ForgeAiPanel, null)
          )
        )
      );
    }
  });
})();
